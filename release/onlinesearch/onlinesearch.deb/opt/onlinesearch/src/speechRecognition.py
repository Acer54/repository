#!/usr/bin/env python
# -*- coding: utf-8 -*-
#######################################################################
# Problems:
#File "/home/matthias/PycharmProjects/Projects/onlinesearch/src/speechRecognition.py", line 24, in startup
#    stingResult = str(result)
#UnicodeEncodeError: 'ascii' codec can't encode character u'\xdf' in position 20: ordinal not in range(128)
#########################################################################
try:
    import speech_recognition as sr
except ImportError:
    print("Speech-Recodnition will not be available")
import sys


def main(arg):
    mylistener = listener()
    mylistener.startup()

class listener(object):

    def __init__(self):

        self.r = sr.Recognizer("de")
        self.r.energy_threshold = 100   # minimum audio energy to consider for recording
        self.r.pause_threshold = 0.3    # seconds of quiet time before a phrase is considered complete
        self.r.quiet_duration = 0.2     # amount of quiet time to keep on both sides of the recording

    def startup(self):

        with sr.Microphone() as source:                # use the default microphone as the audio source
            audio = self.r.listen(source)                   # listen for the first phrase and extract it into audio data

        try:
            result = self.r.recognize(audio)           # recognize speech using Google Speech Recognition
            stingResult = unicode(result)
            stingResult = stingResult.split()
            if len(stingResult) > 2:
                print("Searching for Keyword...")
                maybeKeyword = stingResult[-2:][0]
                maybeKeyword = maybeKeyword.replace("at", "@", 1).replace("App", "@", 1)

                if maybeKeyword == "@":
                    phrase = "%s %s%s" % (" ".join(stingResult[:-2]), maybeKeyword, " ".join(stingResult[-1:]))
                else:
                    phrase = "%s %s %s" % (" ".join(stingResult[:-2]), maybeKeyword, " ".join(stingResult[-1:]))
            else:
                phrase = " ".join(stingResult)

            print(phrase.lstrip())
            return phrase.lstrip()
        except LookupError:                            # speech is unintelligible
            return ""

if __name__ == "__main__":
    main(sys.argv)