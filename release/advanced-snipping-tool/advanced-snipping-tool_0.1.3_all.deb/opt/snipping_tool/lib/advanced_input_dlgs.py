#!/usr/bin/env python
# -*- coding: utf-8 -*-

#############################################################################
# Advanced Input Dialog:
# Bring up an input Dialog which returns not only the entered text, but also
# the chosen font (QFont())
# See Usage below
#############################################################################

import sip
sip.setapi('QString', 1)

from PyQt4.QtGui import QComboBox, QLabel, QFont, QLineEdit, QDialog, QFontComboBox, QPushButton, QHBoxLayout, \
    QVBoxLayout, QFontDatabase, QWidgetAction, QColor, QWidget, QGridLayout, QMenu, QColorDialog, QPixmap, \
    QToolButton, QIcon, QApplication
from PyQt4.QtCore import Qt, pyqtSignal, SIGNAL, QPoint, QString


class LM_advanced_inputDialog_TEXT_FONT(QDialog):

    def __init__(self):
        super(LM_advanced_inputDialog_TEXT_FONT, self).__init__()

        self.displayFont = QFont()
        ###################################################### Define Items
        fontLabel = QLabel("Font:")
        self.fontCombo = QFontComboBox()
        self.fontCombo.setEditable(False)
        sizeLabel = QLabel("Size:")
        self.sizeCombo = QComboBox()
        styleLabel = QLabel("Style:")
        self.styleCombo = QComboBox()
        self.findStyles(self.fontCombo.currentFont())
        self.findSizes(self.fontCombo.currentFont())
        self.lineEdit = QLineEdit()
        self.btn_ok = QPushButton("Ok")
        self.btn_nok = QPushButton("Abbrechen")
        #################################################### Setup Connections
        self.fontCombo.currentFontChanged.connect(self.findStyles)
        self.fontCombo.currentFontChanged.connect(self.findSizes)
        self.fontCombo.activated[str].connect(self.updateFont)
        self.styleCombo.activated[str].connect(self.updateStyle)
        self.sizeCombo.currentIndexChanged[str].connect(self.updateSize)
        self.sizeCombo.highlighted[str].connect(self.updateSize)
        self.btn_ok.clicked.connect(self.accept)
        self.btn_nok.clicked.connect(self.reject)
        ################################################### Setup Layouts
        controlsLayout = QHBoxLayout()
        controlsLayout.addWidget(fontLabel)
        controlsLayout.addWidget(self.fontCombo, 1)
        controlsLayout.addWidget(sizeLabel)
        controlsLayout.addWidget(self.sizeCombo, 1)
        controlsLayout.addWidget(styleLabel)
        controlsLayout.addWidget(self.styleCombo, 1)
        controlsLayout.addStretch(1)

        lineLayout = QHBoxLayout()
        lineLayout.addWidget(self.lineEdit, 1)

        btnLayout = QHBoxLayout()
        btnLayout.addWidget(self.btn_ok)
        btnLayout.addStretch(1)
        btnLayout.addWidget(self.btn_nok)

        centralLayout = QVBoxLayout()
        centralLayout.addLayout(controlsLayout)
        centralLayout.addLayout(lineLayout)
        centralLayout.addLayout(btnLayout)
        self.setLayout(centralLayout)
        ################################################### Set Window Title
        self.setWindowTitle("Geben Sie Ihren Text ein:")

    def findStyles(self, font):
        fontDatabase = QFontDatabase()
        currentItem = self.styleCombo.currentText()
        self.styleCombo.clear()

        for style in fontDatabase.styles(font.family()):
            self.styleCombo.addItem(style)

        styleIndex = self.styleCombo.findText(currentItem)
        if styleIndex == -1:
            self.styleCombo.setCurrentIndex(0)
        else:
            self.styleCombo.setCurrentIndex(styleIndex)

    def findSizes(self, font):

        fontDatabase = QFontDatabase()
        #currentSize = self.sizeCombo.currentText()
        currentSize = font.pointSize()
        self.sizeCombo.blockSignals(True)
        self.sizeCombo.clear()

        if fontDatabase.isSmoothlyScalable(font.family(), fontDatabase.styleString(font)):
            for size in QFontDatabase.standardSizes():
                self.sizeCombo.addItem(str(size))
                self.sizeCombo.setEditable(True)
        else:
            for size in fontDatabase.smoothSizes(font.family(), fontDatabase.styleString(font)):
                self.sizeCombo.addItem(str(size))
                self.sizeCombo.setEditable(False)

        self.sizeCombo.blockSignals(False)

        sizeIndex = self.sizeCombo.findText(str(currentSize))
        if sizeIndex == -1:
            self.sizeCombo.setCurrentIndex(max(0, self.sizeCombo.count() / 3))
        else:
            self.sizeCombo.setCurrentIndex(sizeIndex)

    def updateFont(self, fontFamily):
        self.displayFont.setFamily(fontFamily)
        self.lineEdit.setFont(self.displayFont)

    def updateSize(self, fontSize):
        fontSize, _ = fontSize.toInt()
        self.displayFont.setPointSize(fontSize)
        self.lineEdit.setFont(self.displayFont)

        sizeIndex = self.sizeCombo.findText(str(fontSize))
        if sizeIndex == -1:
            self.sizeCombo.setCurrentIndex(max(0, self.sizeCombo.count() / 3))
        else:
            self.sizeCombo.setCurrentIndex(sizeIndex)

        self.adjustSize()

    def updateStyle(self, fontStyle):
        fontDatabase = QFontDatabase()
        oldStrategy = self.displayFont.styleStrategy()
        self.displayFont = fontDatabase.font(self.displayFont.family(),
                fontStyle, self.displayFont.pointSize())
        self.displayFont.setStyleStrategy(oldStrategy)
        self.lineEdit.setFont(self.displayFont)

    def get_text(self):

        ret = self.exec_()
        if ret == QDialog.Accepted:
            return self.displayFont, self.lineEdit.text()
        else:
            return None, None


class LM_advanced_inputDialog_TEXT_FONT_COLOR(QDialog):

    def __init__(self):
        super(LM_advanced_inputDialog_TEXT_FONT_COLOR, self).__init__()
        #self.setAttribute(Qt.WA_TranslucentBackground)

        self.displayFont = QFont()
        ###################################################### Define Items
        fontLabel = QLabel(u"Schriftart:")
        self.fontCombo = QFontComboBox()
        self.fontCombo.setEditable(False)
        self.fontCombo.setFocusPolicy(Qt.NoFocus)
        sizeLabel = QLabel(u"Größe:")
        self.sizeCombo = QComboBox()
        self.sizeCombo.setFocusPolicy(Qt.ClickFocus)
        styleLabel = QLabel(u"Style:")
        self.styleCombo = QComboBox()
        self.styleCombo.setFocusPolicy(Qt.NoFocus)
        colorLabel = QLabel(u"Farbe:")
        self.colorButton = QColorButton(self)
        self.colorButton.setFocusPolicy(Qt.NoFocus)
        self.lineEdit = QLineEdit()

        self.findStyles(self.fontCombo.currentFont())
        self.findSizes(self.fontCombo.currentFont())

        self.btn_ok = QPushButton(u"Einfügen")
        self.btn_nok = QPushButton(u"Abbrechen")
        #################################################### Setup Connections
        self.fontCombo.currentFontChanged.connect(self.findStyles)
        self.fontCombo.currentFontChanged.connect(self.findSizes)
        self.fontCombo.activated[str].connect(self.updateFont)
        self.styleCombo.activated[str].connect(self.updateStyle)
        self.sizeCombo.currentIndexChanged[str].connect(self.updateSize)
        self.sizeCombo.highlighted[str].connect(self.updateSize)
        self.colorButton.colorChanged.connect(self.updateColor)
        self.btn_ok.clicked.connect(self.accept)
        self.btn_nok.clicked.connect(self.reject)
        ################################################### Setup Layouts
        controlsLayout = QHBoxLayout()
        controlsLayout.addWidget(fontLabel)
        controlsLayout.addWidget(self.fontCombo, 1)
        controlsLayout.addWidget(sizeLabel)
        controlsLayout.addWidget(self.sizeCombo, 1)
        controlsLayout.addWidget(styleLabel)
        controlsLayout.addWidget(self.styleCombo, 1)
        controlsLayout.addWidget(colorLabel)
        controlsLayout.addWidget(self.colorButton, 1)
        controlsLayout.addStretch(1)

        lineLayout = QHBoxLayout()
        lineLayout.addWidget(self.lineEdit, 1)

        btnLayout = QHBoxLayout()
        btnLayout.addWidget(self.btn_ok)
        btnLayout.addStretch(1)
        btnLayout.addWidget(self.btn_nok)

        centralLayout = QVBoxLayout()
        centralLayout.addLayout(controlsLayout)
        centralLayout.addLayout(lineLayout)
        centralLayout.addLayout(btnLayout)
        self.setLayout(centralLayout)
        ################################################### Set Window Title
        self.setWindowTitle("Geben Sie Ihren Text ein:")
        self.updateColor()
        self.updateSize(QString("36"))

    def findStyles(self, font, styleName=None):

        fontDatabase = QFontDatabase()
        currentItem = self.styleCombo.currentText()
        self.styleCombo.clear()

        for style in fontDatabase.styles(font.family()):
            self.styleCombo.addItem(style)

        if styleName is None:
            styleIndex = self.styleCombo.findText(currentItem)
        else:
            styleIndex = self.styleCombo.findText(styleName)

        if styleIndex == -1:
            self.styleCombo.setCurrentIndex(0)
        else:
            self.styleCombo.setCurrentIndex(styleIndex)

    def findSizes(self, font):

        currentSize = font.pointSize()
        self.sizeCombo.blockSignals(True)
        self.sizeCombo.clear()

        for size in QFontDatabase.standardSizes():
            self.sizeCombo.addItem(str(size))
            self.sizeCombo.setEditable(False)

        self.sizeCombo.blockSignals(False)

        sizeIndex = self.sizeCombo.findText(str(currentSize))
        if sizeIndex == -1:
            self.sizeCombo.setCurrentIndex(max(0, self.sizeCombo.count() / 3))
        else:
            self.sizeCombo.setCurrentIndex(sizeIndex)

    def updateFont(self, fontFamily):
        self.displayFont.setFamily(fontFamily)
        self.lineEdit.setFont(self.displayFont)

    def updateSize(self, fontSize):
        if not isinstance(fontSize, int):
            fontSize, _ = fontSize.toInt()
        self.displayFont.setPointSize(fontSize)
        self.lineEdit.setFont(self.displayFont)

        sizeIndex = self.sizeCombo.findText(str(fontSize))
        if sizeIndex == -1:
            self.sizeCombo.setCurrentIndex(max(0, self.sizeCombo.count() / 3))
        else:
            self.sizeCombo.setCurrentIndex(sizeIndex)
        self.adjustSize()

    def updateStyle(self, fontStyle):
        fontDatabase = QFontDatabase()
        oldStrategy = self.displayFont.styleStrategy()
        self.displayFont = fontDatabase.font(self.displayFont.family(),
                fontStyle, self.displayFont.pointSize())
        self.displayFont.setStyleStrategy(oldStrategy)
        self.lineEdit.setFont(self.displayFont)

    def updateColor(self):
        color = self.colorButton.color()
        self.lineEdit.setStyleSheet("background: transparent; color: rgba{0}".format(color.getRgb()))

    def get_text(self):

        ret = self.exec_()
        if ret == QDialog.Accepted:
            return self.displayFont, self.lineEdit.text()
        else:
            return None, None

    def get_color(self):
        return self.colorButton.color()


class ColorAction(QWidgetAction):
    colorSelected = pyqtSignal(QColor)

    def __init__(self, parent):
        QWidgetAction.__init__(self, parent)
        widget = QWidget(parent)
        layout = QGridLayout(widget)
        layout.setSpacing(0)
        layout.setContentsMargins(2, 2, 2, 2)
        palette = self.palette()
        count = len(palette)
        print(count)
        rows = count / round(count ** .5)
        print(rows)
        for row in range(int(rows)):
            for column in range(int(count // rows)):
                color = palette.pop()
                button = QToolButton(widget)
                button.setAutoRaise(True)
                button.clicked[()].connect(
                    lambda color=color: self.handleButton(color))
                pixmap = QPixmap(16, 16)
                pixmap.fill(color)
                button.setIcon(QIcon(pixmap))
                layout.addWidget(button, row, column)
        self.setDefaultWidget(widget)

    def handleButton(self, color):
        self.parent().hide()
        self.colorSelected.emit(color)

    def palette(self):

        palette = []
        palette.append(QColor(Qt.black))
        palette.append(QColor(Qt.white))
        palette.append(QColor(Qt.red))
        palette.append(QColor(Qt.darkRed))
        palette.append(QColor(Qt.blue))
        palette.append(QColor(Qt.darkBlue))
        palette.append(QColor(Qt.green))
        palette.append(QColor(Qt.darkGreen))
        palette.append(QColor(Qt.yellow))

        return palette

class ColorMenu(QMenu):
    def __init__(self, parent):
        QMenu.__init__(self, parent)
        self.colorAction = ColorAction(self)
        self.colorAction.colorSelected.connect(self.handleColorSelected)
        self.addAction(self.colorAction)

    def handleColorSelected(self, color):
        self.color_atMenu = color
        self.emit(SIGNAL("colorChanged_atMenu()"))

    def get_color(self):
        return self.color_atMenu

class QColorButton(QPushButton):
    '''
    Custom Qt Widget to show a chosen color.

    Left-clicking the button shows the color-chooser, while
    right-clicking resets the color to None (no-color).
    '''

    colorChanged = pyqtSignal()

    def __init__(self, parent, *args, **kwargs):
        super(QColorButton, self).__init__(*args, **kwargs)
        self.parent = parent
        self._color = QColor(Qt.red)
        self.setMaximumWidth(32)
        self.myMenu = ColorMenu(self)
        self.pressed.connect(self.onColorPicker)
        self.connect(self.myMenu, SIGNAL("colorChanged_atMenu()"), self.handleMenu)

        self.setColor(self._color)

    def handleMenu(self):
        color = self.myMenu.get_color()
        self.setColor(color)

    def setColor(self, color):
        if color != self._color:
            self._color = color
            self.colorChanged.emit()
        if self._color:
            self.setStyleSheet("QPushButton {background-color: %s;"
                               "border-style: outset;"
                               "border-width: 1px;"
                               "border-radius: 10px;"
                               "border-color: beige;"
                               "min-width: 2em;"
                               "padding: 4px;}" % self._color.name())
        else:
            self.setStyleSheet("")

    def color(self):
        return self._color

    def set_color(self, color):
        if isinstance(color, QColor):
            self._color = color

    def onColorPicker(self):
        '''
        Show color-picker dialog to select color.

        Qt will use the native dialog by default.

        '''
        dlg = QColorDialog(self.parent)
        if self._color:
            dlg.setCurrentColor(self._color)

        if dlg.exec_():
            self.setColor(dlg.currentColor())

    def mousePressEvent(self, e):
        if e.button() == Qt.RightButton:
            point = QPoint()
            point.setX(e.x())   # -links +rechts
            point.setY(e.y() +10)   # -oben +unten
            self.myMenu.exec_(self.mapToGlobal(point))

        return super(QColorButton, self).mousePressEvent(e)



if __name__ == '__main__':
    app = QApplication([])
    ############################################################## USAGE:
    #font = QFont()
    #text = QString()
    #color = QColor()
    font, text = LM_advanced_inputDialog_TEXT_FONT_COLOR().get_text()
    if font is not None:
        print("Font:",font.toString().split(",")[0])
        print("Bold:",font.bold())
        print("Cursive:",font.italic())
        print("Size:",font.pointSize())
        print("Text:", text)
        try:
            color = LM_advanced_inputDialog_TEXT_FONT_COLOR().get_color()
            print("Farbe:", color.getRgb())
        except:
            print("Farbe: Keine (Schwarz)")