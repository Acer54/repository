#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
TODO:
Folgende Funktionen sind noch erwünscht:

-Marker-Funktion (halbtransparent, gelb oder evtl. auch Farbe nach Wahl ....)

-Screenshot: Freihand ausschneiden
-Extra: Senden via Email

-Alle Funktionen mit Doc-Strings beschreiben

"""

import sys
import random
import tempfile
import os
import time
from time import strftime, localtime
import res_crop

from PyQt4.QtCore import QSize, SIGNAL, QVariant, Qt, QThread, QRect, QPoint, pyqtSlot, QSettings, QLocale, QTranslator, \
    QLibraryInfo, QPointF, pyqtSignal, QLineF
from PyQt4.QtGui import QMainWindow, QDesktopWidget, QIcon, QAction, QPixmap, QLabel, QPainter, QApplication, QPrinter, \
    QBrush, QMessageBox, QMenu, QKeySequence, QPen, QPainterPath, QColor, QWidgetAction, QToolButton, QStatusBar, \
    QScrollArea, QSizePolicy, QComboBox, QSpinBox, QToolBar, QProgressBar, QDialog, QWidget, QHBoxLayout, QPushButton, \
    QFileDialog, QGridLayout, QColorDialog, QDesktopServices, QPrintPreviewDialog, QTransform

from lib.area_selector import AreaSelector
from lib.advanced_input_dlgs import LM_advanced_inputDialog_TEXT_FONT_COLOR as LM_input_dlg


__version__ = "0.1.2"

class snipping_tool(QMainWindow):

    def __init__(self, parent=None):
        QMainWindow.__init__(self,parent)
        self.setWindowIcon(self.generateIcon())
        self.__setupUI()

        self.metaObject().connectSlotsByName(self)
        screen = QDesktopWidget().screenGeometry()
        self.setMaximumWidth(screen.width() / 1.2)
        self.setMaximumHeight(screen.height() / 1.2)
        self.setMinimumWidth(620)
        self.setMinimumHeight(200)

        self.statusbar.showMessage(u"Fertig", 5000)
        self.favoriteFileExtention = "png"
        self.undoList = []
        self.filesToDelete = []

        self.__checkActions()

    def generateIcon(self):
        '''
        see http://www.thankcoder.com/questions/jyzag/window-icon-does-not-show
        :return: QIcon with different sizes (used as an application icon)
        '''
        app_icon = QIcon()
        #app_icon.addFile(os.path.join(os.path.dirname(os.path.realpath(__file__)), 'res', '16x16.png'), QSize(16, 16))
        #app_icon.addFile(os.path.join(os.path.dirname(os.path.realpath(__file__)), 'res', '22x22.png'), QSize(22, 22))
        #app_icon.addFile(os.path.join(os.path.dirname(os.path.realpath(__file__)), 'res', '24x24.png'), QSize(24, 24))
        #app_icon.addFile(os.path.join(os.path.dirname(os.path.realpath(__file__)), 'res', '32x32.png'), QSize(32, 32))
        #app_icon.addFile(os.path.join(os.path.dirname(os.path.realpath(__file__)), 'res', '48x48.png'), QSize(48, 48))
        #app_icon.addFile(os.path.join(os.path.dirname(os.path.realpath(__file__)), 'res', '64x64.png'), QSize(64, 64))
        #app_icon.addFile(os.path.join(os.path.dirname(os.path.realpath(__file__)), 'res', '96x96.png'), QSize(96, 96))
        #app_icon.addFile(os.path.join(os.path.dirname(os.path.realpath(__file__)), 'res', '128x128.png'), QSize(128, 128))
        #app_icon.addFile(os.path.join(os.path.dirname(os.path.realpath(__file__)), 'res', '192x192.png'), QSize(192, 192))
        #app_icon.addFile(os.path.join(os.path.dirname(os.path.realpath(__file__)), 'res', '256x256.png'), QSize(256, 256))

        app_icon.addFile(':/16x16.png', QSize(16, 16))
        app_icon.addFile(':/22x22.png', QSize(22, 22))
        app_icon.addFile(':/24x24.png', QSize(24, 24))
        app_icon.addFile(':/32x32.png', QSize(32, 32))
        app_icon.addFile(':/48x48.png', QSize(48, 48))
        app_icon.addFile(':/64x64.png', QSize(64, 64))
        app_icon.addFile(':/96x96.png', QSize(96, 96))
        app_icon.addFile(':/128x128.png', QSize(128, 128))
        app_icon.addFile(':/192x192.png', QSize(192, 192))
        app_icon.addFile(':/256x256.png', QSize(256, 256))
        return app_icon

    def __setupUI(self):
        '''
        __setupUI is only called during __init__ (only once) it contructs the Window and its contents
        like buttons, layouts, connections and so on.
        The nested functions are called from inside.
        So you do only call "self.__setupIU()".
        '''

        def __setupItems(self):
            #self.presentationArea = QLabel()
            self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
            self.presentationArea = presentationArea()
            self.presentationArea.setContextMenuPolicy(Qt.CustomContextMenu)
            self.scrollArea = QScrollArea()
            self.scrollArea.setWidget(self.presentationArea)
            self.scrollArea.setWidgetResizable(True)


            self.cB_zoom = QComboBox()
            self.cB_zoom.addItems(["100%", "75%", "50%", "25%"])

            self.cB_delay = QSpinBox()
            self.cB_delay.setMaximum(10)
            self.cB_delay.setPrefix("in ")
            self.cB_delay.setSuffix(" sec.")

            self.toolbar = QToolBar()
            self.toolbar.setContextMenuPolicy(Qt.CustomContextMenu)
            self.toolbar.setToolButtonStyle(0)

            self.edit_toolbar = QToolBar()
            self.edit_toolbar.setContextMenuPolicy(Qt.CustomContextMenu)
            self.edit_toolbar.setToolButtonStyle(0)

            self.statusbar = QStatusBar()
            self.progressbar = QProgressBar(self.statusbar)
            self.statusbar.addPermanentWidget(self.progressbar)
            self.statusbar.addPermanentWidget(self.cB_zoom)
            self.progressbar.setSizePolicy(QSizePolicy.MinimumExpanding, QSizePolicy.Preferred)
            self.progressbar.setMaximumWidth(100)
            self.progressbar.setMinimum(0)
            self.progressbar.setMaximum(100)
            self.progressbar.setValue(0)
            self.progressbar.setVisible(False)

            self.AreaSelector = AreaSelector()

            self.spacer = QWidget()
            self.spacer.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)

            ############################################################################
            self.dialog = QDialog()
            self.colorButton = QColorButton(self.dialog)
            self.colorButton.setColor(self.presentationArea.arrowPenColor)
            self.sB_size = QSpinBox()
            self.sB_size.setMinimum(2)

            self.sB_size.setMaximum(8)
            self.layout = QHBoxLayout()
            self.layout.addWidget(self.sB_size)
            self.layout.addWidget(self.colorButton)
            self.dialog.setLayout(self.layout)

            self.dialog.setWindowFlags(Qt.WindowStaysOnTopHint)
            self.colorButton.colorChanged.connect(self.setColorForArrow)
            self.sB_size.valueChanged.connect(self.presentationArea.setArrowWidth)
            self.sB_size.setValue(self.presentationArea.arrowPen.width())

        def __setupLayout(self):
            #self.setCentralWidget(self.presentationArea)
            self.setCentralWidget(self.scrollArea)
            self.addToolBar(Qt.TopToolBarArea, self.toolbar)
            self.addToolBar(Qt.LeftToolBarArea, self.edit_toolbar)
            #Qt::ToolButtonIconOnly	        0	Only display the icon.
            #Qt::ToolButtonTextOnly	        1	Only display the text.
            #Qt::ToolButtonTextBesideIcon	2	The text appears beside the icon.
            #Qt::ToolButtonTextUnderIcon	3	The text appears under the icon.
            #Qt::ToolButtonFollowStyle	    4	Follow the system style.
            self.setStatusBar(self.statusbar)

        def __setupActions(self):

            self.exitACT = QAction(QIcon.fromTheme("exit"),
                                                 "&Beenden",
                                                 self,
                                                 shortcut=QKeySequence.Quit,
                                                 statusTip=u"Beendet die Anwendung",
                                                 triggered=self.close)

            self.shotCompleteDesktopACT = QAction(QIcon.fromTheme("video-display"),
                                               "&Screenshot (ganzer Bildschirm)",
                                               self,
                                               shortcut=QKeySequence('Ctrl+Shift+P'),
                                               statusTip=u"Erstellt ein Bildschirmfoto des gesamten Desktops",
                                               triggered=self.on_shotCompleteDesktop)

            self.shotAreaDesktopACT = QAction(QIcon.fromTheme("camera-photo"),
                                              "S&creenshot (Bereichsauswahl)",
                                              self,
                                              shortcut=QKeySequence('Ctrl+Shift+S'),
                                              statusTip=u"Erstellt ein Bildschirmfoto eines ausgewählten Bereichs",
                                              triggered=self.on_shotAreaDesktop)

            self.mirrorVerticalACT = QAction(QIcon(":/flip-vertical.png"),
                                              "Vertikal spiegeln",
                                              self,
                                              statusTip=u"Bild Vertikal spiegeln",
                                              triggered=self.mirrorVert)

            self.mirrorHorizontalACT = QAction(QIcon(":/flip-horizontal.png"),
                                              "Horizontal spiegeln",
                                              self,
                                              statusTip=u"Bild Horizontal spiegeln",
                                              triggered=self.mirrorHor)

            self.rotateClockwiseACT = QAction(QIcon(":/rotate.png"),
                                              "Bild im Uhrzeigersinn drehen",
                                              self,
                                              statusTip=u"Bild im Uhrzeigersinn drehen",
                                              triggered=self.rotateClockwise)

            self.undoACT = QAction(QIcon(":/undo.png"),
                                              u"Rückgängig",
                                              self,
                                              shortcut=QKeySequence.Undo,
                                              statusTip=u"letzte Änderung rückgängig machen",
                                              triggered=self.undo)

            self.saveAsACT = QAction(QIcon.fromTheme("document-save-as"),
                                              u"Speichern unter...",
                                              self,
                                              shortcut=QKeySequence.Save,
                                              statusTip=u"aktuelles Bild speichern",
                                              triggered=self.saveAs)

            self.druckenACT = QAction(QIcon.fromTheme("printer"),
                                              u"Drucken",
                                              self,
                                              shortcut=QKeySequence.Print,
                                              statusTip=u"aktuelles Bild drucken",
                                              triggered=self.drucken)

            self.copyToClipboardACT = QAction(QIcon.fromTheme("edit-copy"),
                                              u"Kopieren",
                                              self,
                                              shortcut=QKeySequence.Copy,
                                              statusTip=u"aktuelles Bild in die Zwischenablage kopieren",
                                              triggered=self.copyToClipboard)

            self.zoom_inACT = QAction(QIcon.fromTheme("zoom-in"),
                                              u"Zoom +",
                                              self,
                                              shortcut=QKeySequence.ZoomIn,
                                              statusTip=u"aktuelles Bild vergrößern",
                                              triggered=self.zoom_in)

            self.zoom_outACT = QAction(QIcon.fromTheme("zoom-out"),
                                              u"Zoom -",
                                              self,
                                              shortcut=QKeySequence.ZoomOut,
                                              statusTip=u"aktuelles Bild verkleinern",
                                              triggered=self.zoom_out)

            self.mark_ArrowACT = QAction(QIcon(":/arrow.png"),
                                              u"Pfeil einfügen",
                                              self,
                                              statusTip=u"Fügt einen Pfeil zur Markierung ein, (abbrechen mit <ESC>)",
                                              triggered=self.mark_Arrow)


            self.cropACT = QAction(QIcon(":/crop.png"),
                                              u"Zuschneiden",
                                              self,
                                              shortcut=QKeySequence.Cut,
                                              statusTip=u"Bild zuschneiden",
                                              triggered=self.crop)

            self.paintingACT = QAction(QIcon(":/pencil.png"),
                                              u"Zeichnen",
                                              self,
                                              statusTip=u"Freihand zeichnen",
                                              triggered=self.freeHandPainting)

            self.paintingBUT = QPushButton()
            self.paintingBUT.setCheckable(True)
            self.paintingBUT.setIcon(QIcon(":/pencil.png"))

            self.rectPaintingACT = QAction(QIcon(":/rect.png"),
                                           u"Rechteck zeichnen",
                                           self,
                                           statusTip=u"Rechteckige Markierung zeichnen",
                                           triggered=self.mark_Rect)

            self.ellipsePaintingACT = QAction(QIcon(":/ellipse.png"),
                                           u"Ellipse zeichnen",
                                           self,
                                           statusTip=u"Runde Markierung zeichnen",
                                           triggered=self.mark_Ellipse)

            self.addTextACT = QAction(QIcon(":/text.png"),
                                           u"Text hinzufügen",
                                           self,
                                           statusTip=u"Fügt einen Text hinzu",
                                           triggered=self.addText)

        def __setupToolbar(self):

            self.toolbar.addAction(self.shotCompleteDesktopACT)
            self.toolbar.addWidget(self.cB_delay)
            self.toolbar.addSeparator()
            self.toolbar.addAction(self.shotAreaDesktopACT)
            self.toolbar.addAction(self.copyToClipboardACT)
            self.toolbar.addAction(self.saveAsACT)
            self.toolbar.addAction(self.druckenACT)
            self.toolbar.addAction(self.undoACT)
            self.toolbar.addSeparator()
            self.toolbar.addAction(self.zoom_inACT)
            self.toolbar.addAction(self.zoom_outACT)
            self.toolbar.addWidget(self.spacer)
            self.toolbar.addAction(self.exitACT)

            self.edit_toolbar.addAction(self.cropACT)
            self.edit_toolbar.addAction(self.mirrorVerticalACT)
            self.edit_toolbar.addAction(self.mirrorHorizontalACT)
            self.edit_toolbar.addAction(self.rotateClockwiseACT)
            self.edit_toolbar.addAction(self.mark_ArrowACT)
            self.edit_toolbar.addAction(self.rectPaintingACT)
            self.edit_toolbar.addAction(self.ellipsePaintingACT)
            self.edit_toolbar.addWidget(self.paintingBUT)
            self.edit_toolbar.addAction(self.addTextACT)

        def __setupMenuBar(self):
            self.fileMenu = self.menuBar().addMenu("&Datei")

            self.fileMenu.addAction(self.shotCompleteDesktopACT)
            self.fileMenu.addAction(self.shotAreaDesktopACT)
            self.fileMenu.addAction(self.saveAsACT)
            self.fileMenu.addAction(self.druckenACT)
            self.fileMenu.addSeparator()
            self.fileMenu.addAction(self.exitACT)

            self.editMenu = self.menuBar().addMenu("&Bearbeiten")
            self.editMenu.addAction(self.undoACT)
            self.editMenu.addAction(self.copyToClipboardACT)
            self.editMenu.addAction(self.zoom_inACT)
            self.editMenu.addAction(self.zoom_outACT)
            self.editMenu.addAction(self.mirrorHorizontalACT)
            self.editMenu.addAction(self.mirrorVerticalACT)
            self.editMenu.addAction(self.rotateClockwiseACT)

            self.extrasMenu = self.menuBar().addMenu("&Extras")
            self.extrasMenu.addAction(self.mark_ArrowACT)
            self.extrasMenu.addAction(self.rectPaintingACT)
            self.extrasMenu.addAction(self.ellipsePaintingACT)
            self.extrasMenu.addAction(self.cropACT)
            self.extrasMenu.addAction(self.addTextACT)

            self.menuBar().addSeparator()

            self.helpMenu = self.menuBar().addMenu("&Help")

        def __setupConnections(self):
            self.connect(self.AreaSelector, SIGNAL("screenshot_ready(QString)"), self.updateLabel)
            self.connect(self, SIGNAL("screenshot_ready(QString)"), self.updateLabel)
            self.connect(self.AreaSelector, SIGNAL("screenshot_aborted()"), self.showMessage_)
            self.presentationArea.customContextMenuRequested.connect(self.createContextMenue)

            self.connect(self.presentationArea, SIGNAL("drawing_finished()"), self.tempsavePresentationArea)
            self.scrollArea.horizontalScrollBar().valueChanged.connect(self.presentationArea.update)  #avoid some display problems
            self.scrollArea.verticalScrollBar().valueChanged.connect(self.presentationArea.update)
            #self.cB_delay.valueChanged.connect(self.dummy)

            self.cB_zoom.currentIndexChanged.connect(self.zoom)
            self.connect(self, SIGNAL("zoom_changed(int)"), self.on_zoom_changed)
            self.connect(self, SIGNAL("change_zoom(int)"), self.zoom)
            self.paintingBUT.clicked.connect(self.freeHandPainting)

        def __moveCenter(self):
            """
            Placing the windows in the middle of the screen
            """
            screen = QDesktopWidget().screenGeometry()
            size =  self.geometry()
            self.move((screen.width()-size.width())/2, (screen.height()-size.height())/2)

        __setupItems(self)
        __setupLayout(self)
        __setupActions(self)
        __setupToolbar(self)
        __setupMenuBar(self)
        __setupConnections(self)
        __moveCenter(self)
        self.readSettings()

    def __checkActions(self):
        '''
        __checkActions function is setting Actions to Enabled or Disabled depending on some conditions.
        this function is called during runtime, so it is not possible to nest it in any way.
        '''
        self.undoACT.setEnabled(True if len(self.undoList) > 1 else False)
        self.rotateClockwiseACT.setEnabled(True if len(self.undoList) > 0 else False)
        self.mirrorHorizontalACT.setEnabled(True if len(self.undoList) > 0 else False)
        self.mirrorVerticalACT.setEnabled(True if len(self.undoList) > 0 else False)
        self.saveAsACT.setEnabled(True if len(self.filesToDelete) > 0 else False)
        self.druckenACT.setEnabled(True if len(self.filesToDelete) > 0 else False)
        self.copyToClipboardACT.setEnabled(True if len(self.filesToDelete) > 0 else False)
        self.zoom_inACT.setEnabled(True if (len(self.filesToDelete) > 0 and self.cB_zoom.currentIndex() != 0)
                                   else False)
        self.zoom_outACT.setEnabled(True if (len(self.filesToDelete) > 0 and self.cB_zoom.currentIndex() != 3)
                                    else False)
        self.cB_zoom.setEnabled(True if len(self.filesToDelete) > 0 else False)
        self.mark_ArrowACT.setEnabled(True if len(self.filesToDelete) > 0 else False)
        self.addTextACT.setEnabled(True if len(self.filesToDelete) > 0 else False)
        self.cropACT.setEnabled(True if len(self.filesToDelete) > 0 else False)
        self.paintingBUT.setEnabled(True if len(self.filesToDelete) > 0 else False)
        self.rectPaintingACT.setEnabled(True if len(self.filesToDelete) > 0 else False)
        self.ellipsePaintingACT.setEnabled(True if len(self.filesToDelete) > 0 else False)

        if self.filesToDelete > 0:
            if self.presentationArea.global_freeHandPainting:
                self.undoACT.setEnabled(False)
                self.rotateClockwiseACT.setEnabled(False)
                self.mirrorHorizontalACT.setEnabled(False)
                self.mirrorVerticalACT.setEnabled(False)
                self.saveAsACT.setEnabled(False)
                self.druckenACT.setEnabled(False)
                self.copyToClipboardACT.setEnabled(False)
                self.zoom_inACT.setEnabled(False)
                self.zoom_outACT.setEnabled(False)
                self.cB_zoom.setEnabled(False)
                self.mark_ArrowACT.setEnabled(False)
                self.cropACT.setEnabled(False)
                self.ellipsePaintingACT.setEnabled(False)
                self.rectPaintingACT.setEnabled(False)

            if self.presentationArea.global_croping:
                self.undoACT.setEnabled(False)
                self.rotateClockwiseACT.setEnabled(False)
                self.mirrorHorizontalACT.setEnabled(False)
                self.mirrorVerticalACT.setEnabled(False)
                self.saveAsACT.setEnabled(False)
                self.druckenACT.setEnabled(False)
                self.copyToClipboardACT.setEnabled(False)
                self.zoom_inACT.setEnabled(False)
                self.zoom_outACT.setEnabled(False)
                self.cB_zoom.setEnabled(False)
                self.mark_ArrowACT.setEnabled(False)
                self.paintingBUT.setEnabled(False)
                self.ellipsePaintingACT.setEnabled(False)
                self.rectPaintingACT.setEnabled(False)

            if self.presentationArea.global_ArrowMarking:
                self.undoACT.setEnabled(False)
                self.rotateClockwiseACT.setEnabled(False)
                self.mirrorHorizontalACT.setEnabled(False)
                self.mirrorVerticalACT.setEnabled(False)
                self.saveAsACT.setEnabled(False)
                self.druckenACT.setEnabled(False)
                self.copyToClipboardACT.setEnabled(False)
                self.zoom_inACT.setEnabled(False)
                self.zoom_outACT.setEnabled(False)
                self.cB_zoom.setEnabled(False)
                self.cropACT.setEnabled(False)
                self.paintingBUT.setEnabled(False)
                self.ellipsePaintingACT.setEnabled(False)
                self.rectPaintingACT.setEnabled(False)

            if self.presentationArea.global_RectPainting:
                self.undoACT.setEnabled(False)
                self.cropACT.setEnabled(False)
                self.rotateClockwiseACT.setEnabled(False)
                self.mirrorHorizontalACT.setEnabled(False)
                self.mirrorVerticalACT.setEnabled(False)
                self.saveAsACT.setEnabled(False)
                self.druckenACT.setEnabled(False)
                self.copyToClipboardACT.setEnabled(False)
                self.zoom_inACT.setEnabled(False)
                self.zoom_outACT.setEnabled(False)
                self.cB_zoom.setEnabled(False)
                self.mark_ArrowACT.setEnabled(False)
                self.paintingBUT.setEnabled(False)
                self.ellipsePaintingACT.setEnabled(False)


            if self.presentationArea.global_EllipsePainting:
                self.undoACT.setEnabled(False)
                self.cropACT.setEnabled(False)
                self.rotateClockwiseACT.setEnabled(False)
                self.mirrorHorizontalACT.setEnabled(False)
                self.mirrorVerticalACT.setEnabled(False)
                self.saveAsACT.setEnabled(False)
                self.druckenACT.setEnabled(False)
                self.copyToClipboardACT.setEnabled(False)
                self.zoom_inACT.setEnabled(False)
                self.zoom_outACT.setEnabled(False)
                self.cB_zoom.setEnabled(False)
                self.mark_ArrowACT.setEnabled(False)
                self.paintingBUT.setEnabled(False)
                self.rectPaintingACT.setEnabled(False)

    ############################################################ Settingsmanagement
    def readSettings(self):
        '''
        Read system specific settings if there are any.
        '''

        settings = QSettings("Laumer", "snipping_tool")
        ######################################################## SIZE
        size = settings.value("MainWindow/Size",
                              QVariant(QSize(620, 200))).toSize()
        self.resize(size)
        ######################################################## Standard-Storage-location
        cwd = settings.value("cwd", QVariant(QDesktopServices.storageLocation(QDesktopServices.PicturesLocation)))
        self.saveAs_path = cwd.toString()
        if not os.path.exists(self.saveAs_path):
            self.saveAs_path = None
            #This should happen, if the last saved path was a external (e.g. USB-Stick)
            #if self.saveAs_path is "None" a default path is chosen in self.saveAs() (picturelocation)
        custom_pos = settings.value("geometry").toByteArray()
        if not custom_pos.isEmpty():
            #if value geometry was not set befor, an empty ByteArry will be returned by .toByteArray()
            self.restoreGeometry(custom_pos)

    def writeSettings(self):
        '''
        Write current settings in storage of OS
        '''
        settings = QSettings("Laumer", "snipping_tool")
        settings.setValue("MainWindow/Size", QVariant(self.size()))
        settings.setValue("cwd", QVariant(self.saveAs_path))
        settings.setValue("geometry", self.saveGeometry())

    ############################################################ All about ZOOM
    def zoom_in(self):
        '''
        called by pressing the "+" Button, or Menu/zoom in
        '''
        current_zoom = self.cB_zoom.currentIndex()
        if not current_zoom == 0:
            self.zoom_outACT.setEnabled(True)
            self.zoom(current_zoom-1)
            self.cB_zoom.setCurrentIndex(current_zoom-1)
            if (current_zoom -1) == 0:
                self.zoom_inACT.setEnabled(False)
        else:
            self.zoom_inACT.setEnabled(False)

    def zoom_out(self):
        '''
        called by pressing the "-" Button, or Menu/zoom out
        '''
        current_zoom = self.cB_zoom.currentIndex()
        if not current_zoom == 3:
            self.zoom_inACT.setEnabled(True)
            self.zoom(current_zoom+1)
            self.cB_zoom.setCurrentIndex(current_zoom+1)
            if (current_zoom +1) == 3:
                self.zoom_outACT.setEnabled(False)
        else:
            self.zoom_outACT.setEnabled(False)

    def zoom(self, level=None):
        """
        :param level:
                          0 = 100%
                          1 = 75%
                          2 = 50%
                          3 = 25%
        """
        translation = {0:1,
                       1:0.75,
                       2:0.50,
                       3:0.25}

        if level is not None:
            self.presentationArea.zoomTo(translation[level])
            self.emit(SIGNAL("zoom_changed(int)"), level)           # Signal is connected to self.on_zoom_changed()
        else:
            return translation[self.cB_zoom.currentIndex()]

    def on_zoom_changed(self, level):
        '''

        :param level: current zoom level 0 = 100%
                                         1 = 75%
                                         2 = 50%
                                         3 = 25%
        The zoom_level can be changed by clicking, changing different things (Buttons, the Menue...)
        To keep the Combo-Box syncronus , every time the zoom_changed Signal is triggered, also the current index
        from the combo Box changes.
        '''
        if self.cB_zoom.currentIndex() != level:
            self.cB_zoom.setCurrentIndex(level)

    ############################################################ Screenshot functions
    def on_shotCompleteDesktop(self):
        """
        Takes a screenshot of the complete Desktop.
        :return: save it temporary with calling "tempsavePicture" and update the presentationArea
        """

        self.hide()
        time.sleep(.4) # wait a little bit until the window is hidden....

        delay = self.cB_delay.value()
        completeScreenPixmap = self.AreaSelector.shotScreen(delay)

        self.tempsavePicture(completeScreenPixmap)

    def on_shotAreaDesktop(self):
        """
        Takes a screenshot of a priviouselly selected area by using the spezial Area-Selector see "lib/AreaSelector.py"
        Befor calling the AreaSelector, it also hides the mainwindow, to avoid that it is visible during screenshot
        """
        self.hide()
        self.AreaSelector.show_selection_area()

    ############################################################ Funtion to update the Presentation Area
    def updateLabel(self, arg=None):
        """
        This function is connected to the signal "screenshot_ready"
        :param arg: path to a file, which should be shown. (it the arg is not a path, an empty pixmap will be created
        :return: displays the picture in the arg given in the presentationArea
        """
        print("Update Label")
        if self.isHidden():                      # if the windows is hidden at the time the funciton is called, show it
            self.show()
        if os.path.isfile(unicode(arg)):         # if the arg which is given is a file, open it
            originalImage = QPixmap(unicode(arg)) # save it to a variable
            self.presentationArea.setOriginalPicture(originalImage)
            self.filesToDelete.append(unicode(arg))    # append the file to the list of files which should be deleted
        else:
            originalImage = QPixmap()       # if the path is NO file, create an empty pixmap
            self.presentationArea.setOriginalPicture(originalImage)


        image = originalImage.scaled(originalImage.width()*self.zoom(),
                                          originalImage.height()*self.zoom(),
                                          Qt.KeepAspectRatio,
                                          Qt.SmoothTransformation)

        self.presentationArea.setFixedSize(image.size())
        self.presentationArea.setPixmap(image)    # show the given (and maybe scaled) Pixmap in presentationArea
        #if the user have not defined the size of Mainwindow, adjust it according to the pixmap
        if (self.presentationArea.height()*1.1) > self.height():
            self.resize(self.width(), self.presentationArea.height()*1.1)
        if (self.presentationArea.width()*1.1) > self.width():
            self.resize(self.presentationArea.width()*1.1,self.height())

        # check if there is already a file in the undo-list, if yes, check if the last file in the list is NOT the same
        # as the actually called file, it this is also the case, append it to the end of the list
        # if the undo-list is empty, just store it ot it.
        # so if the same file is called twice, it would not be appended to the undo list, because it is already the last
        # state.
        if len(self.undoList) > 0:
            if not self.undoList[-1] == unicode(arg):
                self.undoList.append(unicode(arg))
                #print("Undolist updated with:", unicode(arg), self.undoList)
        elif len(self.undoList) == 0:
            self.undoList.append(unicode(arg))
            #print("Undolist initialised with", unicode(arg), self.undoList)

        self.__checkActions()  #update the action in toolbar,menuebar and contextMenue, depending on what is the
                               #current state.

    ############################################################ All about Painting, marking, (toolbar-Buttons)
    def undo(self):
        """
        called by self.undoACT, (from Toolbar, Menue and Contextmenue)
        changes the content of the presentation-Area to the last stored Picture, this means "undo" the last action,
        what ever was stored in /tmp/

        :return: True or False
        """
        if len(self.undoList) > 1:
            self.undoList.pop(-1)
            lastFile = self.undoList.pop(-1)
            self.emit(SIGNAL("screenshot_ready(QString)"), lastFile)
            self.statusbar.showMessage(u"Rückgängig erfolgreich.", 5000)
            return True
        else:
            print("Undo not possible", self.undoList)
            return False

    def mirrorVert(self):
        """
        This action is disabled if no picture is loaded !
        It is triggered generally by the QAction self.mirrorVertACT
        The function takes the original Picture (full size) and mirror it vertically

        :return: saves the new picture with "tempsavePicture", from there also a "screenshot_ready" Signal will be
        emitted.
        """

        picture = self.presentationArea.getOriginalPicture()
        newPicture = picture.toImage()
        newPicture = newPicture.mirrored(False, True)
        self.statusbar.showMessage(u"Spiegeln: Screenshot vertical gespiegelt.", 5000)
        self.tempsavePicture(newPicture)

    def mirrorHor(self):
        """
        This action is disabled if no picture is loaded !
        It is triggered generally by the QAction self.mirrorHorACT
        The function takes the original Picture (full size) and mirror it horizontally

        :return: saves the new picture with "tempsavePicture", from there also a "screenshot_ready" Signal will be
        emitted.
        """

        picture = self.presentationArea.getOriginalPicture()
        newPicture = picture.toImage()
        newPicture = newPicture.mirrored(True, False)
        self.statusbar.showMessage(u"Spiegeln: Screenshot horizontal gespiegelt.", 5000)
        self.tempsavePicture(newPicture)

    def rotateClockwise(self):
        """
        This action is disabled if no picture is loaded !
        It is triggered generally by the QAction self.rotateClockwiseACT
        The function takes the original Picture (full size) and rotate it clockwise per 90 degree steps

        :return: saves the new picture with "tempsavePicture", from there also a "screenshot_ready" Signal will be
        emitted.
        """

        picture = self.presentationArea.getOriginalPicture()
        myTransformation = QTransform()
        myTransformation.rotate(90)
        newPicture = picture.transformed(myTransformation)
        self.statusbar.showMessage(u"Rotieren: Screenshot um 90° rotiert.", 5000)
        self.tempsavePicture(newPicture)

    def mark_Arrow(self):
        """
        This action is disabled if no picture is loaded !
        It is triggered generally by the QAction self.mark_ArrowACT
        The function takes the original Picture (full size) and activates the "activate_ArrowMarking()" function
        from the class presentation Area

        :return: saves the new picture with "tempsavePicture", from there also a "screenshot_ready" Signal will be
        emitted.
        """
        if not self.presentationArea.drawing:

            self.storedZoomfactor = self.cB_zoom.currentIndex()
            #self.emit(SIGNAL("change_zoom(int)"), 0)  #zoom to 100%
            self.presentationArea.activate_ArrowMarking()
            self.__checkActions()

            position = QPoint()
            position.setX(self.pos().x()+80)
            position.setY(self.pos().y()+60)
            self.dialog.move(position)
            self.dialog.show()

    def mark_Rect(self):
        if not self.presentationArea.drawing:
            self.storedZoomfactor = self.cB_zoom.currentIndex()
            #self.emit(SIGNAL("change_zoom(int)"), 0)  #zoom to 100%
            self.presentationArea.activate_rectPainting()

            self.__checkActions()

            position = QPoint()
            position.setX(self.pos().x()+80)
            position.setY(self.pos().y()+60)
            self.dialog.move(position)
            self.dialog.show()

    def mark_Ellipse(self):
        if not self.presentationArea.drawing:
            self.storedZoomfactor = self.cB_zoom.currentIndex()
            #self.emit(SIGNAL("change_zoom(int)"), 0)  #zoom to 100%
            self.presentationArea.activate_ellipsePainting()

            self.__checkActions()

            position = QPoint()
            position.setX(self.pos().x()+80)
            position.setY(self.pos().y()+60)
            self.dialog.move(position)
            self.dialog.show()

    def freeHandPainting(self):
        if self.paintingBUT.isChecked():
            if self.presentationArea.drawing:
                self.paintingBUT.setChecked(False)
                return

            self.storedZoomfactor = self.cB_zoom.currentIndex()
            #self.emit(SIGNAL("change_zoom(int)"), 0)  #zoom to 100%
            self.presentationArea.activate_painting()
            self.__checkActions()

            position = QPoint()
            position.setX(self.pos().x()+80)
            position.setY(self.pos().y()+60)
            self.dialog.move(position)
            self.dialog.show()
        else:
            self.__checkActions()
            self.tempsavePresentationArea()

    def setColorForArrow(self):
        color = self.colorButton.color()
        if color.isValid():
            self.presentationArea.setArrowColor(color)

    def crop(self):

        self.presentationArea.activate_cropping()
        self.statusbar.showMessage(u"Ausschneiden: Drücken Sie <Enter> um die Aktion ab zu schließen", 5000)

    def addText(self):
        if not self.presentationArea.drawing:
            if self.presentationArea.textLine_marked is not None:      # if the user clicked "anywere" excepting a textLine
                    self.presentationArea.textLine_marked = None   # if not forget about the marking and mark None.
                    self.tempsavePresentationArea()
                    self.moving = False

            self.storedZoomfactor = self.cB_zoom.currentIndex()
            self.presentationArea.zoomTo()
            self.__checkActions()
            self.dlg = LM_input_dlg()
            font, text = self.dlg.get_text()
            if font is not None:
                self.statusbar.showMessage(u"Sie können den Text nun verschieben und mittels Doppelklick editieren", 10000)
                #print("Font:",font.toString().split(",")[0])
                #print("Bold:",font.bold())
                #print("Cursive:",font.italic())
                #print("Size:",font.pointSize())
                #print("Text:", text)
                color = self.dlg.get_color()
                #print("Farbe:", color.getRgb())

                self.presentationArea.textLines.append(Text_entry(font,text,color))
                self.presentationArea.update()
            else:
                self.emit(SIGNAL("change_zoom(int)"), self.storedZoomfactor)

    ########################################################### All about Saving Files, temporary or not
    def tempsavePresentationArea(self):
        if not self.presentationArea.global_croping:

            if not self.presentationArea.drawing:
                self.unsetCursor()
                if self.dialog:
                    if self.dialog.isVisible():
                            self.dialog.hide()
            #pixmap = QPixmap()
            #pixmap = pixmap.grabWidget(self.presentationArea)
            if self.presentationArea.global_ArrowMarking:
                pixmap = self.presentationArea.finish_arrowMarking()
            elif self.presentationArea.global_RectPainting:
                pixmap = self.presentationArea.finish_rectPainting()
            elif self.presentationArea.global_EllipsePainting:
                pixmap = self.presentationArea.finish_ellipsePainting()
            elif self.presentationArea.global_freeHandPainting:
                pixmap = self.presentationArea.finish_painting()
            elif len(self.presentationArea.textLines) > 0:
                pixmap = self.presentationArea.finish_textLine()
            else:
                print("Problem during Tempsaving Presentation Area ... debug")

            if self.dialog.isVisible():
                self.dialog.hide()
            if self.tempsavePicture(pixmap):
                self.presentationArea.resetCurrentDrawing()

            self.emit(SIGNAL("change_zoom(int)"), self.storedZoomfactor)
            self.__checkActions()

    def tempsavePicture(self, pixmap):
        """
        :param pixmap: pixmapObject which should be saved temporary in temp folder
        :return: true or false, depending on if the operation was sucessfull or not
        If the operation was sucessfull, the signal "screenshot_ready" will be emitted, which triggers the update
        of presentation area (see setup_connections)
        """

        dir = tempfile.gettempdir()
        filename = random.randint(1,900)
        extension = self.favoriteFileExtention

        filename = os.path.join(dir, "{0}.{1}".format(filename, extension))

        try:
            pixmap.save(filename)
            print("saved Pixmap")
            if filename:
                 self.emit(SIGNAL("screenshot_ready(QString)"), filename)
                 print("screenshot ready...")
                 self.statusbar.showMessage(u"Zwischenspeichern: {0}".format(filename), 1000)
                 return True
            else:
                print("something went wringe during storage")
                return False

        except IOError as err:
            print("An Error occured during saving changed image in your temporary folder:", err)
            self.askQuestion("Es trat ein Problem auf! Aktion abgebrochen!", "Ok", ("%s" %err))

            return False

    def saveAs(self):
        """
        Brings up a Save-As Dialog, the path and filename can be entered.
        Default is the systems Picture-Path and the filename which is including date and time
        :return: True or False if the operation was cancelled.
        """

        if self.presentationArea.textLine_marked is not None:      # if the user clicked "anywere" excepting a textLine
            self.presentationArea.textLine_marked = None   # if not forget about the marking and mark None.
            self.tempsavePresentationArea()
            self.moving = False

        if self.saveAs_path is None:
            path = QDesktopServices.storageLocation(QDesktopServices.PicturesLocation)
        else:
            path = self.saveAs_path

        suggestion = strftime("Screenshot_%a-%d-%b-%Y-%H-%M-%S.png", localtime())
        fileName = QFileDialog.getSaveFileName(self,
                                               u"Wählen Sie den Speicherort, sowie den Dateinamen:",
                                               (os.path.join(unicode(path), unicode(suggestion.decode("utf-8")))),
                                               u"Bild-Datei (*.png *.jpg)")
        if fileName.isEmpty():
            print("Save-As, was aborted")
            self.statusbar.showMessage(u"Aktion abgebrochen", 1000)
            return False
        else:
            image = self.presentationArea.getOriginalPicture()
            image.save(fileName)
            self.saveAs_path = os.path.dirname(str(unicode(fileName).encode("utf-8")).decode("utf-8"))
            self.statusbar.showMessage(u"Screenshot erfolgreich gespeichert.", 1000)
            return True

    ########################################################### Clipboard
    def copyToClipboard(self):
        """
        Copy the current Picture to the systems clipboard...
        """
        clipboard = QApplication.clipboard()
        clipboard.setPixmap(self.presentationArea.getOriginalPicture())
        self.statusbar.showMessage(u"Screenshot in die Zwischenablage kopiert.", 1000)

    ########################################################### All about printing
    def drucken(self):
        """
        This function is called from the druckenACT (Print-Button), it brings up a preview dialog, were some
        settings can be made for printing, and the printing can be startet (in a File, or to a printer)
        :return: Shows PrinterPreviewDialog as a Modal window
        """
        if self.presentationArea.textLine_marked is not None:      # if the user clicked "anywere" excepting a textLine
            self.presentationArea.textLine_marked = None   # if not forget about the marking and mark None.
            self.tempsavePresentationArea()
            self.moving = False

        self.printerobject = QPrinter(0)
        self.printerobject.setPaperSize(0)           # QPrinter::A4	Value: 0	210 x 297 mm, 8.26 x 11.69 inches
        self.printerobject.setOrientation(QPrinter.Landscape)

        printdialog = QPrintPreviewDialog(self.printerobject)

        printdialog.paintRequested.connect(self.drucken_renderer) # connect the paint request to the renderer
        printdialog.exec_()                                       # show the dialog as a modal window

    def drucken_renderer(self):
        """
        This function is connected to the paintRequested Signal from the PrintPreviewDialog (see self.drucken).
        Is is called from the dialog if it wants to update the preview and need a render action
        :return: rendering stream
        """

        # get papersize in pixels:
        pagesize = self.printerobject.paperRect()

        # get picturesize in pixels:
        picturesize = self.presentationArea.getOriginalPicture().size()
        # compare sizes, if picturesize is larger, then papersize, resize the picture to match the papersize
        if self.printerobject.orientation() == QPrinter.Landscape:
            if picturesize.width() > pagesize.width or picturesize.height() > pagesize.height():
                picture = self.presentationArea.getOriginalPicture().scaled(pagesize.width() -50, pagesize.height()-50,
                                                Qt.KeepAspectRatio, Qt.SmoothTransformation)
            else:
                picture = self.presentationArea.getOriginalPicture()
        else:
            if picturesize.height() > pagesize.width or picturesize.width() > pagesize.height():
                print("scaling")
                picture = self.presentationArea.getOriginalPicture().scaled(pagesize.width() -50, pagesize.height()-50,
                                                Qt.KeepAspectRatio, Qt.SmoothTransformation)
            else:
                picture = self.presentationArea.getOriginalPicture()

        content = QLabel()                                 # Need a widget which can render a pixmap
        content.setPixmap(picture)                         # set the original size of the current Pixmap

        return content.render(QPainter(self.printerobject))

    ########################################################### helper Functions which can be called by Signals.
    def createContextMenue(self, point):   # called with presentationArea.customContextMenuRequested
        """
        This cuntion is a customContextMenue of the presentation Area, it will be called with a right-click on the
        presentationArea.
        :param point: Qpoint, where the action was triggered.
        :return: brings up a context-menue which is almost the same, than in toolbar and menuebar.
        """
        #correct offset
        point.setX(point.x())   # -links +rechts
        point.setY(point.y() +40)   # -oben +unten

        self.copyToClipboardACT.setIconVisibleInMenu(True)
        self.saveAsACT.setIconVisibleInMenu(True)
        self.druckenACT.setIconVisibleInMenu(True)
        self.cropACT.setIconVisibleInMenu(True)
        self.mark_ArrowACT.setIconVisibleInMenu(True)
        self.mirrorHorizontalACT.setIconVisibleInMenu(True)
        self.mirrorVerticalACT.setIconVisibleInMenu(True)
        self.rotateClockwiseACT.setIconVisibleInMenu(True)
        self.undoACT.setIconVisibleInMenu(True)
        self.addTextACT.setIconVisibleInMenu(True)


        self.owncontextMenue = QMenu()
        self.owncontextMenue.addAction(self.copyToClipboardACT)
        self.owncontextMenue.addAction(self.saveAsACT)
        self.owncontextMenue.addAction(self.druckenACT)
        self.owncontextMenue.addAction(self.cropACT)
        self.owncontextMenue.addAction(self.mark_ArrowACT)
        self.owncontextMenue.addAction(self.mirrorHorizontalACT)
        self.owncontextMenue.addAction(self.mirrorVerticalACT)
        self.owncontextMenue.addAction(self.rotateClockwiseACT)
        self.owncontextMenue.addAction(self.undoACT)
        self.owncontextMenue.addAction(self.addTextACT)

        self.owncontextMenue.exec_(self.mapToGlobal(point))

    @pyqtSlot(int)              # call with Signal "setProgressValueSIG(int)", int
    def setProgressValue(self, value=100):
        '''
        With the signal "setProgressValueSIG(int)", int you can set the progressbar to a specific value.
        (Note that this function need an overloaded signal (with an integer).
        The integer can be processed if it is between -2 and 100

        :param value:       -1      = Start "pulsing" progressbar (bar is moving from left to right)
                            -2      = Stop  "pulsing" progressbar to 100%, wait 2 Seconds, then HIDE Progressbar
                            0 - 99  = Setting the displayed Value in Progressbar to the given Value
                            <empty> = Setting the Progressbar-Value to the default (100) which will also hide it.
                            100     = same like receiving an empty value
        :return:
        '''

        if value == -1:
            print("Start Pulsing...")
            self.progressbar.setVisible(True)
            self.progressbar.setRange(0,0)
            self.progressbar.setValue(0)
            return

        if value == -2:
            print("Stop Pulsing...")
            self.progressbar.setVisible(True)
            self.progressbar.setRange(0,100)
            self.progressbar.setValue(100)
            QThread.sleep(2)
            self.setProgressValue(100)
            return


        self.progressbar.setRange(0,100)
        self.progressbar.setVisible(True)
        self.progressbar.setValue(value)

        if value == 100:
            self.progressbar.setVisible(False)

    def askQuestion(self, text1, btn1, text2=None, btn2=None):
        """
        This functions shows a pop-up-window, which is marked as a "question"
        :param text1: First Text-Line (necessary)
        :param btn1:  First Button    (necessary)
        :param text2: Second Text-Line(optional)
        :param btn2:  Second Button   (optional)
        :return: 1(firstButton) or 0 (secondButton) was clicked.
        """
        text1 = unicode(text1)
        btn1 = unicode(btn1)
        msgBox = QMessageBox()
        msgBox.setIcon(QMessageBox.Question)
        msgBox.setText("%s" % text1.decode("utf-8"))
        if text2 is not None: msgBox.setInformativeText("%s" % text2.decode("utf-8"))
        msgBox.addButton("%s" % btn1.decode("utf-8"), QMessageBox.ActionRole)                             # ret = 0
        if btn2 is not None: msgBox.addButton("%s" % btn2.decode("utf-8"), QMessageBox.RejectRole)        # ret = 2
        ret = msgBox.exec_()
        ret = int(ret)

        if ret == 0:
            return 0       # Result Button 1 (OK)
        else:
            return 1       # Result Button 2 (Cancel)

    def showMessage_(self):
        """
        Displays an Error-Message in statusbar
        """
        self.show()
        self.statusbar.showMessage("Aktion Abgebrochen", 5000)

    # ########################################################## Reimplemented functions with helper functions
    def keyPressEvent(self, QKeyEvent):
        if QKeyEvent.key() == Qt.Key_Escape:
            if self.presentationArea.drawing:
                self.unsetCursor()
                if self.dialog.isVisible():
                    self.dialog.hide()
                self.presentationArea.deactivate_Drawing()
                self.showMessage_()
                self.__checkActions()

        if QKeyEvent.key() == Qt.Key_Return:
            if self.presentationArea.drawing:
                if self.presentationArea.global_croping:
                    self.storedZoomfactor = self.cB_zoom.currentIndex()
                    pixmap = self.presentationArea.finish_cropping()
                    if self.tempsavePicture(pixmap):
                        self.presentationArea.resetCurrentDrawing()
                        self.emit(SIGNAL("change_zoom(int)"), self.storedZoomfactor)

        if QKeyEvent.key() == Qt.Key_Delete:
            if self.presentationArea.textLine_marked is not None:
                self.unsetCursor()
                self.presentationArea.textLines = []
                self.presentationArea.textLine_marked = None
                self.presentationArea.moving = False
                self.presentationArea.repaint()

    def resizeEvent(self, QResizeEvent):
        QResizeEvent.accept()

    def closeEvent(self, QCloseEvent):
        """
        Re-Implementation of CloseEvent
        Befor the close-Event will be executed, some final aktions will be made (like cleaning the temp-files)
        which where created during runtime

        :param QCloseEvent: QCloseEvent
        :return: Accept after final actions
        """
        self.cleanTempFiles()
        self.writeSettings()
        if self.dialog.isVisible():
            self.dialog.close()

        QCloseEvent.accept()

    def cleanTempFiles(self):     # is executed just befor closure
        """
        File which were created during runtime will be logged in a file-list, files which are existing at time of
        closure, will be deleted.
        """

        for file in self.filesToDelete:
            if os.path.isfile(file):
                try:

                    os.remove(file)
                except OSError as err:
                    print(err)
        self.filesToDelete = []

    ############################################################ Only a dummy function to test some things

    def dummy(self):
        print("Dummy-Action")


class presentationArea(QLabel):

    def __init__(self, parent = None):
        QLabel.__init__(self, parent)

        self.global_freeHandPainting = False
        self.drawing = False
        self.global_ArrowMarking = False
        self.global_EllipsePainting = False
        self.global_RectPainting = False
        self.global_croping = False
        self.global_RectCroping = False
        self.dragging = None
        self.moving = False

        self.lastMousePosition = QPoint(0,0)
        self.currentMousePosition = QPoint(0,0)
        self.originalPicture = None
        self.lines = []
        self.storedLines=[]
        self.freeHandPathes=[]
        self.storedFreeHandPathes=[]
        self.textLines=[]
        self.textLine_marked=None
        self.rectPaintingPath=None
        self.rectCropingPath=None
        self.storedRectPaintingPathes=[]
        self.ellipsePaintingPath=None
        self.storedEllipsePaintingPathes=[]
        self.clip_rect = QRect(50,50,100,100)
        self.largest_rect = QRect(self.rect())
        self.cropBoarder = 10
        self.gridDistance = 3
        self.zoomlevel = 1
        self.arrowPen = QPen()
        self.setArrowPen()

    def setOriginalPicture(self, QPixmap):
        self.originalPicture = QPixmap

    def getOriginalPicture(self):
        return self.originalPicture

    def zoomTo(self, level=1):

        self.zoomlevel = level
        if self.originalPicture is None:
            self.originalPicture = self.pixmap().copy()
        newPic = self.originalPicture.scaled(self.originalPicture.width()*level,
                                                   self.originalPicture.height()*level,
                                                   Qt.KeepAspectRatio,
                                                   Qt.SmoothTransformation)
        oldRect = self.rect() #save OLD Rect (size with current zoomfactor)
        self.setPixmap(newPic)
        self.setFixedSize(self.pixmap().size())

        newRect = self.rect() #save NEW Rect (size with NEW zoomfactor)

        if self.global_croping:
            startPoint = self.clip_rect.topLeft()
            endPoint = self.clip_rect.bottomRight()

            correctedStartPoint, correctedEndPoint = self.mapToFullsize(oldRect, newRect, startPoint, endPoint)

            # defene the two points which are the same relative from oldZoomFactor to new
            self.clip_rect.setTopLeft(correctedStartPoint)
            self.clip_rect.setBottomRight(correctedEndPoint)

        if self.global_ArrowMarking:
            templist = []
            for line in self.storedLines:
                startPoint= line.p1()
                endPoint = line.p2()
                correctedStartPoint, correctedEndPoint = self.mapToFullsize(oldRect, newRect, startPoint, endPoint)
                line.setP1(correctedStartPoint)
                line.setP2(correctedEndPoint)
                templist.append(line)

            self.storedLines = templist

        if self.global_RectPainting:
            templist = []
            for path in self.storedRectPaintingPathes:
                startPoint = path.topLeft()
                endPoint = path.bottomRight()
                correctedStartPoint, correctedEndPoint = self.mapToFullsize(oldRect, newRect, startPoint, endPoint)
                path.setTopLeft(correctedStartPoint)
                path.setBottomRight(correctedEndPoint)
                templist.append(path)

            self.storedRectPaintingPathes = templist

        if self.global_EllipsePainting:
            templist = []
            for path in self.storedEllipsePaintingPathes:
                startPoint = path.topLeft()
                endPoint = path.bottomRight()
                correctedStartPoint, correctedEndPoint = self.mapToFullsize(oldRect, newRect, startPoint, endPoint)
                path.setTopLeft(correctedStartPoint)
                path.setBottomRight(correctedEndPoint)
                templist.append(path)

            self.storedEllipsePaintingPathes = templist

        if self.global_freeHandPainting:
            templist = []

            for line in self.storedFreeHandPathes:

                element = line.elementAt(0)

                startPoint = QPointF(element.x, element.y)
                endPoint = line.currentPosition()
                correctedStartPoint, correctedEndPoint = self.mapToFullsize(oldRect, newRect, startPoint, endPoint)
                newLine = QPainterPath(correctedStartPoint)
                newLine.lineTo(correctedEndPoint)
                templist.append(newLine)

            self.storedFreeHandPathes = templist


        self.update()

    def mapToFullsize(self, RectOLD_size, RectNEW_size, startpount, endpoint):
        """
        Takes an "old" Areasize in form of an QRect, an new, which is larger, or smaler, two pounts, which can be
        the topLeft, bottomRight OṔoint of a QRect or two points, like a start and an endpoint of any line...

        :param RectOLD_size: QRect(befor zooming)
        :param RectNEW_size: QRect(after zooming)
        :param startpount: First point
        :param endpoint: Second point

        :return: two point, which are matching the position in the NEW_Rect like the did initially in the OLD_Rect
        """
        xStartPunkt_markiert = float(startpount.x()) / float(RectOLD_size.width())
        #print(xStartPunkt_markiert, self.rect().width()) #die markierung startet bei 0.316916488223 (31%)

        yStartPunkt_markiert = float(startpount.y()) / float(RectOLD_size.height())
        #print(yStartPunkt_markiert, self.rect().height()) #die markierung startet bei 0.316916488223 (31%)

        xEndPunkt_markiert = float(endpoint.x()) / float(RectOLD_size.width())
        #print(xEndPunkt_markiert)  # bei 0.756102783726 der gesamten Breite ist Markierungsende (75%)

        yEndPunkt_markiert = float(endpoint.y()) / float(RectOLD_size.height())
        #print(yEndPunkt_markiert) #die markierung endet bei 0.65....(65%, von oben)

        correctedStartPoint = QPoint((round(RectNEW_size.width() * xStartPunkt_markiert)),
                                     (round(RectNEW_size.height() * yStartPunkt_markiert)))

        correctedEndPoint = (QPoint((round(RectNEW_size.width() * xEndPunkt_markiert)),
                                    (round(RectNEW_size.height() * yEndPunkt_markiert))))

        return correctedStartPoint, correctedEndPoint

    def resetCurrentDrawing(self):
        self.lines = []
        self.storedLines=[]
        self.freeHandPathes=[]
        self.storedFreeHandPathes=[]
        self.rectPaintingPath = None
        self.storedRectPaintingPathes=[]
        self.ellipsePaintingPath = None
        self.storedEllipsePaintingPathes = []
        #self.textLines=[]
        #self.textLine_marked=None

    def activate_ArrowMarking(self):
        self.setCursor(Qt.CrossCursor)
        self.global_ArrowMarking = True
        self.drawing = True

    def finish_arrowMarking(self):
        self.zoomTo()
        newPicture = QPixmap()
        newPicture = newPicture.grabWidget(self)

        self.global_ArrowMarking = False
        self.drawing = False
        self.unsetCursor()

        return newPicture

    def activate_cropping(self):
        #self.setMouseTracking(True)
        self.setCursor(Qt.CrossCursor)
        #self.global_croping = True
        self.clip_rect = QRect(0,0,0,0)
        self.global_RectCroping = True
        self.global_croping = False
        self.drawing = True
        #print("activate",self.drawing, self.global_croping, self.global_RectCroping)
        self.repaint()

    def finish_cropping(self):
        #restore Zoomlevel
        self.zoomTo()
        newPicture = self.pixmap().copy(self.clip_rect)

        self.global_croping = False
        self.global_RectCroping = False
        self.drawing = False
        self.setMouseTracking(False)
        self.unsetCursor()
        #print("Finished",self.drawing, self.global_croping, self.global_RectCroping)

        return newPicture

    def activate_painting(self):
        self.setCursor(Qt.PointingHandCursor)
        self.global_freeHandPainting = True
        self.drawing = True

    def finish_painting(self):
        self.zoomTo()
        newPicture = QPixmap()
        newPicture = newPicture.grabWidget(self)

        self.global_freeHandPainting = False
        self.drawing = False
        self.unsetCursor()

        return newPicture

    def finish_textLine(self):
        self.zoomTo()
        self.textLine_marked = None
        self.repaint()
        newPicture = QPixmap()
        newPicture = newPicture.grabWidget(self)
        self.unsetCursor()
        self.textLines=[]
        print("Made new Picture of Widget")
        return newPicture

    def activate_rectPainting(self):
        self.setCursor(Qt.CrossCursor)
        self.global_RectPainting = True
        self.drawing = True

    def finish_rectPainting(self):
        self.zoomTo()
        newPicture = QPixmap()
        newPicture = newPicture.grabWidget(self)

        self.global_RectPainting = False
        self.drawing = False
        self.unsetCursor()

        return newPicture

    def activate_ellipsePainting(self):
        self.setCursor(Qt.CrossCursor)
        self.global_EllipsePainting = True
        self.drawing = True

    def finish_ellipsePainting(self):
        self.zoomTo()
        newPicture = QPixmap()
        newPicture = newPicture.grabWidget(self)

        self.global_EllipsePainting = False
        self.drawing = False
        self.unsetCursor()

        return newPicture

    def deactivate_Drawing(self):

        self.unsetCursor()
        self.global_freeHandPainting = False
        self.drawing = False
        self.global_ArrowMarking = False
        self.global_RectPainting = False
        self.global_EllipsePainting = False
        self.global_croping = False
        self.global_RectCroping = False
        self.dragging = False
        self.setMouseTracking(False)
        self.clip_rect = QRect(0,0,0,0)

        self.update()

    def mousePressEvent(self, QMouseEvent):
        pos = QMouseEvent.pos()

        if self.drawing:  # if the usere startet "drawing" befor, by clicking one of the function buttons.
            if self.textLine_marked is not None:      # if the user clicked "a drawing btn" excepting a textLine
                if not self.textLine_marked.get_position().contains(pos):  # check if marked one is still clicked
                    self.textLine_marked = None   # if not forget about the marking and mark None.

            if self.global_ArrowMarking or self.global_freeHandPainting or \
                    self.global_RectPainting or self.global_EllipsePainting:

                self.lastMousePosition = pos
                self.currentMousePosition = pos

            if self.global_RectCroping:
                self.lastMousePosition = pos
                self.currentMousePosition = pos
                self.dragging = 4


            if self.global_croping:
                self.lastMousePosition = pos
                self.currentMousePosition = pos
                for i in range(4):
                    rect = self.corner(i)
                    if rect.contains(pos):
                        self.dragging = i
                        self.drag_offset = rect.topLeft() - pos
                        break
                    else:
                        self.dragging = None

                if self.clip_rect.contains(pos) and self.dragging is None:
                    self.moving = True
                else:
                    self.moving = False
        else: # if the user is not drwaing, but clicked onto the presentation Area, check if the point is anywere on
            if self.textLine_marked is not None:      # if the user clicked "anywere" excepting a textLine
                if not self.textLine_marked.get_position().contains(pos):  # check if marked one is still clicked
                    self.textLine_marked = None   # if not forget about the marking and mark None.
                    self.emit(SIGNAL("drawing_finished()"))  # Trigger snipping tool > TempsavePresentationArea
                    self.moving = False
                else:
                    self.lastMousePosition = pos      # if yes, remember "last" mousposition (which is the current one)
                    self.currentMousePosition = pos
                    self.moving = True                 # set self.moving to "True" (remember, self.drawing stays False)

    def mouseDoubleClickEvent(self, QMouseEvent):
        pos = QMouseEvent.pos()
        if self.textLine_marked is not None:      # if the user doubleclicked "anywere" and one textLine is marked
            if not self.textLine_marked.get_position().contains(pos):  # check if marked one is still clicked
                self.textLine_marked = None   # if not forget about the marking and mark None.
                self.emit(SIGNAL("drawing_finished()"))  # Trigger snipping tool > TempsavePresentationArea
                self.moving = False
            else:
                #open Text again for Editing
                print("open again for Editing")
                self.dlg = LM_input_dlg()
                self.dlg.lineEdit.setText(self.textLine_marked.text)
                self.dlg.displayFont = self.textLine_marked.font
                self.dlg.fontCombo.setCurrentFont(self.textLine_marked.font)
                self.dlg.colorButton.setColor(self.textLine_marked.color)
                self.dlg.updateSize(self.textLine_marked.font.pointSize())
                self.dlg.findStyles(self.textLine_marked.font, self.textLine_marked.font.styleName())

                font, text = self.dlg.get_text()
                if font is not None:
                    self.textLine_marked.text = text
                    self.textLine_marked.color = self.dlg.colorButton.color()
                    self.textLine_marked.font = font
                    #self.textLine_marked.set_position(None)  #position is not changed and stays the same
                    self.repaint()

    def mouseMoveEvent(self, QMouseEvent):

        pos = QMouseEvent.pos()
        if self.drawing:
            if self.global_ArrowMarking:
                self.currentMousePosition = pos
                self.lines = self.paint_arrow(self.lastMousePosition, self.currentMousePosition, self.zoomlevel)

            if self.global_freeHandPainting:
                self.currentMousePosition = pos
                mypath = QPainterPath()
                mypath.moveTo(self.lastMousePosition)
                mypath.lineTo(self.currentMousePosition)
                self.freeHandPathes.append(mypath)
                self.lastMousePosition = pos

            if self.global_RectPainting:
                self.currentMousePosition = pos
                topLeft, botRight = self.turn_to_logical_mousepositions(self.lastMousePosition,
                                                                        self.currentMousePosition)
                self.rectPaintingPath = QRect(topLeft, botRight) #update current rect which is dawing currently

            if self.global_EllipsePainting:
                self.currentMousePosition = pos
                topLeft, botRight = self.turn_to_logical_mousepositions(self.lastMousePosition,
                                                                        self.currentMousePosition)
                self.ellipsePaintingPath = QRect(topLeft, botRight)

            if self.global_RectCroping:
                self.currentMousePosition = pos
                topLeft, botRight = self.turn_to_logical_mousepositions(self.lastMousePosition,
                                                                        self.currentMousePosition)
                #self.rectCropingPath = QRect(topLeft, botRight) #update current rect which is dawing currently
                self.clip_rect = QRect(topLeft, botRight) #update current rect which is dawing currently

            if self.global_croping:
                if self.drawing:
                    left = self.largest_rect.left()
                    right = self.largest_rect.right()
                    top = self.largest_rect.top()
                    bottom = self.largest_rect.bottom()

                    point = pos #+ self.drag_offset
                    point.setX(max(left, min(point.x(), right)))
                    point.setY(max(top, min(point.y(), bottom)))

                    if self.dragging == 0:
                        self.clip_rect.setTopLeft(point)
                    elif self.dragging == 1:
                        self.clip_rect.setTopRight(point)
                    elif self.dragging == 2:
                        self.clip_rect.setBottomLeft(point)
                    elif self.dragging == 3:
                        self.clip_rect.setBottomRight(point)

                    if self.dragging is None and not self.moving:
                        self.currentMousePosition = pos
                        for i in range(4):
                            rect = self.corner(i)

                            if rect.contains(pos):
                                corner = i
                                if i == 0 or i == 3:
                                    self.setCursor(Qt.SizeFDiagCursor)
                                    break
                                elif i == 1 or i == 2:
                                    self.setCursor(Qt.SizeBDiagCursor)
                                    break

                            elif self.clip_rect.contains(pos):
                                self.setCursor(Qt.OpenHandCursor)

                            else:
                                self.unsetCursor()


                    if self.moving:
                        self.setCursor(Qt.ClosedHandCursor)
                        offset = pos - self.lastMousePosition
                        self.lastMousePosition = pos
                        #print(offset.y())
                        #print(offset.x())
                        self.clip_rect.setTopLeft(self.clip_rect.topLeft()+offset)
                        self.clip_rect.setBottomRight(self.clip_rect.bottomRight()+offset)



            self.repaint()

        elif self.moving and not self.drawing:  # if the user wants to move a Text-Line

            if self.textLine_marked is not None:   # check which textLine wants to be moved
                offset = pos - self.lastMousePosition # calculate the movment
                self.lastMousePosition = pos          # update the "lastMouseposition" to the current one
                rectnew = self.textLine_marked.get_position() # define the new rect. (from the Text-object)
                rectnew.setTopLeft(rectnew.topLeft()+offset)
                rectnew.setBottomRight(rectnew.bottomRight()+offset)

            self.repaint()    # repaint.

    def mouseReleaseEvent(self, QMouseEvent):
        pos = QMouseEvent.pos()
        for line in self.lines:         #draw arrows if there are any...
            self.storedLines.append(line)

        if self.rectPaintingPath is not None:
            self.storedRectPaintingPathes.append(self.rectPaintingPath)
            self.rectPaintingPath = None

        if self.ellipsePaintingPath is not None:
            self.storedEllipsePaintingPathes.append(self.ellipsePaintingPath)
            self.ellipsePaintingPath = None

        for path in self.freeHandPathes:
            self.storedFreeHandPathes.append(path)
            self.freeHandPathes = []

        #if self.drawing and self.global_freeHandPainting:
        #    self.emit(SIGNAL("drawing_finished()"))

        if self.drawing and not self.global_croping and not self.global_freeHandPainting and not self.global_RectCroping:
            #self.deactivate_Drawing()
            self.emit(SIGNAL("drawing_finished()"))

        if self.drawing and self.moving:
            self.setCursor(Qt.OpenHandCursor)
            self.moving = None

        if self.global_RectCroping and not self.global_croping:
            print("Setting global_RectCroping to False and cropping to True")
            #self.clip_rect = self.rectCropingPath
            self.setMouseTracking(True)
            self.global_RectCroping = False
            self.global_croping = True

        if self.textLine_marked is not None and self.moving:      # if the user clicked "anywere" excepting a textLine
            self.moving = False

        self.dragging = None
        self.repaint()

    def setArrowPen(self):
        #initial settings for the arrow
        self.arrowPenColor = Qt.red
        self.arrowPen.setColor(self.arrowPenColor)
        self.arrowPen.setWidth(4)
        self.arrowPen.setCapStyle(Qt.RoundCap)
        self.arrowPen.setJoinStyle(Qt.RoundJoin)
        return True

    def setArrowColor(self, color):
        self.arrowPenColor = color
        self.arrowPen.setColor(self.arrowPenColor)

    def setArrowWidth(self, value):
        self.arrowPen.setWidth(value)

    def chooseColor(self):
        #TODO: Move this to Mainwindow
        self.colorDLG = QColorDialog()
        self.colorDLG.setCurrentColor(self.arrowPenColor)
        self.colorDLG.currentColorChanged.connect(self.setArrowColor)
        color = self.colorDLG.getColor()
        if color.isValid():
            self.setArrowColor(color)

    def getArrowPen(self):

        pen = QPen(self.arrowPen) # construct a copy of the current QPen.
        return pen

    def paintEvent(self, event):
        painter = QPainter()
        painter.begin(self)

        if self.pixmap():
            painter.drawPixmap(0,0, self.pixmap())
            ################################################                       Draw all TextLines if there are any
            for text in self.textLines:    # for each entry in self.textLines (TextLine-Objects)
                font = text.font           # select Font  QFont()
                text_string = text.text    # get text     QString()
                color = text.color         # get color    QColor()
                textpen = QPen()           # setup the pen
                textpen.setColor(color)
                painter.setPen(textpen)
                painter.setFont(font)
                if text.get_position() is None:                            # if the textLine was locatet automatically
                    #QRect boundingRect QPainter.drawText (self, Qrect(), int flags, QString text)
                    bounding = painter.drawText(event.rect(), Qt.AlignCenter, text_string)
                    text.set_position(bounding)
                    self.textLine_marked = text  # mark an autoplaced textLine
                else:                                                      # if the position was ever userdefined
                    # if the text was edited, recalculate and show bounding box. (is marked)
                    bounding = painter.drawText(text.get_position(), Qt.AlignCenter, text_string)
                    text.set_position(bounding)
            ##################################################                     Draw selection if there are any
            if self.textLine_marked is not None:
                painter.setPen(QPen(Qt.lightGray, 1, Qt.DashDotLine, Qt.RoundCap, Qt.RoundJoin))
                painter.drawRect(self.textLine_marked.get_position())

        myPen = self.getArrowPen()
        originalWidth = myPen.width()
        adjustedWidth = originalWidth*self.zoomlevel
        myPen.setWidth(adjustedWidth)


        painter.setPen(myPen)

        for line in self.lines:                        # draw Arrows during "creation"
            painter.drawLine(line)

        for line in self.storedLines:                  # draw Arrows when mouse was released.
            painter.drawLine(line)

        for path in self.freeHandPathes:               # draw Freehandpathes during "creation"
            painter.drawPath(path)

        for path in self.storedFreeHandPathes:         # draw Freehandpathes when mouse was released.
            painter.drawPath(path)

        if self.rectPaintingPath is not None:          # draw rect during creation
            painter.drawRect(self.rectPaintingPath)

        for rect in self.storedRectPaintingPathes:     # draw rect when mouse was released.
            painter.drawRect(rect)

        if self.ellipsePaintingPath is not None:       # draw ellipse during creation
            painter.drawEllipse(self.ellipsePaintingPath)

        for ellipse in self.storedEllipsePaintingPathes:  # draw ellipse when mouse was released.
            painter.drawEllipse(ellipse)


        if self.global_croping:

            self.largest_rect = event.rect()

            # Keep the selected Area inside the visible Area and a minimum Size while scrolling

            if self.clip_rect.topLeft().x() < self.largest_rect.topLeft().x():
                self.clip_rect.setTopLeft(QPoint(self.largest_rect.topLeft().x(), self.clip_rect.topLeft().y()))
                if (self.clip_rect.left()+self.cropBoarder+2) > (self.clip_rect.right() - self.cropBoarder -2):
                    self.clip_rect.setTopRight(QPoint(self.clip_rect.topLeft().x()+(self.cropBoarder * 2) +2,
                                                      self.clip_rect.topRight().y()))

            if self.clip_rect.topLeft().y() < self.largest_rect.topLeft().y():
                self.clip_rect.setTopLeft(QPoint(self.clip_rect.topLeft().x(), self.largest_rect.topLeft().y()))
                if (self.clip_rect.top()+self.cropBoarder+2) > (self.clip_rect.bottom() - self.cropBoarder -2):
                    self.clip_rect.setBottomRight(QPoint(self.clip_rect.bottomRight().x(),
                                                         self.clip_rect.topRight().y()+(self.cropBoarder * 2) +2))

            if self.clip_rect.bottomRight().x() > self.largest_rect.bottomRight().x():
                self.clip_rect.setBottomRight(QPoint(self.largest_rect.bottomRight().x(), self.clip_rect.bottomRight().y()))
                if (self.clip_rect.left()+self.cropBoarder+2) > (self.clip_rect.right() - self.cropBoarder -2):
                    self.clip_rect.setTopLeft(QPoint(self.clip_rect.topRight().x()-(self.cropBoarder * 2) -2,
                                                      self.clip_rect.topLeft().y()))

            if self.clip_rect.bottomRight().y() > self.largest_rect.bottomRight().y():
                self.clip_rect.setBottomRight(QPoint(self.clip_rect.bottomRight().x(), self.largest_rect.bottomRight().y()))
                if (self.clip_rect.top()+self.cropBoarder+2) > (self.clip_rect.bottom() - self.cropBoarder -2):
                    self.clip_rect.setTopLeft(QPoint(self.clip_rect.topLeft().x(),
                                                     self.clip_rect.bottomRight().y()-(self.cropBoarder * 2) -2))

        if self.global_croping and not self.global_RectCroping:
            # Keep distance between corners of selected Area higher than 12 pixels (self.cropBoarder + 2) while dragging

            if (self.clip_rect.left()+self.cropBoarder+2) > (self.clip_rect.right() - self.cropBoarder -2):
                if self.dragging == 0 or self.dragging == 2:
                    self.clip_rect.setTopRight(QPoint(self.clip_rect.topLeft().x()+(self.cropBoarder * 2) +2,
                                                      self.clip_rect.topRight().y()))
                if self.dragging == 1 or self.dragging == 3:
                    self.clip_rect.setTopLeft(QPoint(self.clip_rect.topRight().x()-(self.cropBoarder * 2) -2,
                                                      self.clip_rect.topLeft().y()))

            if (self.clip_rect.top()+self.cropBoarder+2) > (self.clip_rect.bottom() - self.cropBoarder -2):
                if self.dragging == 0 or self.dragging == 1:
                    self.clip_rect.setBottomRight(QPoint(self.clip_rect.bottomRight().x(),
                                                         self.clip_rect.topRight().y()+(self.cropBoarder * 2) +2))
                if self.dragging == 2 or self.dragging == 3:
                    self.clip_rect.setTopLeft(QPoint(self.clip_rect.topLeft().x(),
                                                     self.clip_rect.bottomRight().y()-(self.cropBoarder * 2) -2))

        if self.global_croping or self.global_RectCroping:

            if self.clip_rect.height() > event.rect().height(): # or self.clip_rect.width() > event.rect().width():
            #    print("adjusting Rect")
                self.clip_rect = event.rect()
            #print("my event.rect for adjusting is:", event.rect())
            #print("maybe I should use my self.rect...??:", self.rect())
            #print("my clipRect after adjusting is:", self.clip_rect)
            #painter = QPainter()
            #painter.begin(self)
            painter.setRenderHint(QPainter.Antialiasing)

            #painter.drawImage(self.rect(), self.picture)
            # fill none-selected area with gray overlayer...
            #print("filling...")
            mypath = QPainterPath()
            mypath.moveTo(self.clip_rect.topLeft())
            mypath.lineTo(event.rect().topLeft())
            mypath.lineTo(event.rect().topRight())
            mypath.lineTo(event.rect().bottomRight())
            mypath.lineTo(event.rect().bottomLeft())
            mypath.lineTo(event.rect().topLeft())
            mypath.lineTo(self.clip_rect.topLeft())
            mypath.lineTo(self.clip_rect.bottomLeft())
            mypath.lineTo(self.clip_rect.bottomRight())
            mypath.lineTo(self.clip_rect.topRight())
            mypath.lineTo(self.clip_rect.topLeft())
            mypath.closeSubpath()

            painter.fillPath(mypath, QBrush(QColor(0x33, 0x33, 0x33, 0xcc)))

            topRightX = self.clip_rect.x() + self.clip_rect.width()
            bottomY = self.clip_rect.y() + self.clip_rect.height()

            #show gridLines

            if self.dragging is not None:
                painter.setPen(QPen(Qt.lightGray, 1))

                f = 1.0 / self.gridDistance
                wsize = self.clip_rect.width() * f
                hsize = self.clip_rect.height() * f

                gridlines = QPainterPath()

                for i in range(1, self.gridDistance):
                    y = self.clip_rect.y() + i * hsize
                    gridlines.moveTo(self.clip_rect.x(), y)
                    gridlines.lineTo(topRightX, y)


                    for j in range(1, self.gridDistance):
                        x = self.clip_rect.x() + j * wsize
                        gridlines.moveTo(x, self.clip_rect.y())
                        gridlines.lineTo(x, bottomY)

                painter.drawPath(gridlines)


            # Draw Corners
            painter.setPen(QPen(Qt.cyan, 3))

            cropRect = QPainterPath()

            #top Left Corner
            cropRect.moveTo(self.clip_rect.topLeft())
            cropRect.lineTo(self.clip_rect.x() + self.cropBoarder, self.clip_rect.y())
            cropRect.moveTo(self.clip_rect.topLeft())
            cropRect.lineTo(self.clip_rect.x(), self.clip_rect.y() + self.cropBoarder)

            #top Right Corner
            cropRect.moveTo(self.clip_rect.topRight())
            cropRect.lineTo(topRightX - self.cropBoarder, self.clip_rect.y())
            cropRect.moveTo(self.clip_rect.topRight())
            cropRect.lineTo(topRightX, self.clip_rect.y() + self.cropBoarder)

            #bottom right corner
            cropRect.moveTo(self.clip_rect.bottomRight())
            cropRect.lineTo(topRightX - self.cropBoarder, bottomY)
            cropRect.moveTo(self.clip_rect.bottomRight())
            cropRect.lineTo(topRightX, bottomY - self.cropBoarder)

            #bottom left corner
            cropRect.moveTo(self.clip_rect.bottomLeft())
            cropRect.lineTo(self.clip_rect.x() + self.cropBoarder, bottomY)
            cropRect.moveTo(self.clip_rect.bottomLeft())
            cropRect.lineTo(self.clip_rect.x(), bottomY - self.cropBoarder)

            painter.drawPath(cropRect)


        painter.end()

    def paint_arrow(self, startpoint, endpoint, zoomlevel):

        lines = []
        baseline = QLineF(endpoint, startpoint)
        angle = baseline.angle()
        head1 = QLineF(endpoint, startpoint)
        head2 = QLineF(endpoint, startpoint)
        head1.setLength(20*zoomlevel)
        head2.setLength(20*zoomlevel)
        head1.setAngle(angle +30)
        head2.setAngle(angle -30)

        lines= [baseline, head1, head2]

        return lines

    def corner(self, number):

        if number == 0:
            return QRect(self.clip_rect.topLeft() - QPoint(8, 8), QSize(16, 16))
        elif number == 1:
            return QRect(self.clip_rect.topRight() - QPoint(8, 8), QSize(16, 16))
        elif number == 2:
            return QRect(self.clip_rect.bottomLeft()  - QPoint(8, 8), QSize(16, 16))
        elif number == 3:
            return QRect(self.clip_rect.bottomRight() - QPoint(8, 8), QSize(16, 16))

    def turn_to_logical_mousepositions(self, startposition, currentposition):
        '''
        Checks for logical mouse-coordinates, if the user is draging not in bottom-right direction to
        define a rect, elipse or whatelse is dealing wiht "topLeft" and "bottomRight" points.

        startposition: QPoint, that was defined with first click by user
        currentposition: QPoint, where the mouse is at the moment of evaluation
        :return: The right "topLeft" and "bottomRight" position
        '''
        #print("Turning into logical mousepositions")
        if startposition and currentposition:
            firstpoint = startposition
            secondpoint = currentposition
            topLeft = firstpoint
            botRight = secondpoint

            #catch different selection-directions
            if firstpoint.x() < secondpoint.x():
                #moved right
                if firstpoint.y() < secondpoint.y():
                    #moved lower
                    topLeft = firstpoint
                    botRight = secondpoint
                else:
                    #moved higher
                    topLeft = QPoint(firstpoint.x(), secondpoint.y())
                    botRight = QPoint(secondpoint.x(), firstpoint.y())

            else:
                #moved left
                if secondpoint.y() < firstpoint.y():
                    #moved higher
                    topLeft = secondpoint
                    botRight = firstpoint
                else:
                    #moved lower
                    topLeft = QPoint(secondpoint.x(), firstpoint.y())
                    botRight = QPoint(firstpoint.x(), secondpoint.y())

            return topLeft,botRight

        else: # if given mouse-positions are not Valid.
            return QPoint(0,0), QPoint(0,0)


class ColorAction(QWidgetAction):
    colorSelected = pyqtSignal(QColor)

    def __init__(self, parent):
        QWidgetAction.__init__(self, parent)
        widget = QWidget(parent)
        layout = QGridLayout(widget)
        layout.setSpacing(0)
        layout.setContentsMargins(2, 2, 2, 2)
        palette = self.palette()
        count = len(palette)
        print(count)
        rows = count / round(count ** .5)
        print(rows)
        for row in range(int(rows)):
            for column in range(int(count // rows)):
                color = palette.pop()
                button = QToolButton(widget)
                button.setAutoRaise(True)
                button.clicked[()].connect(
                    lambda color=color: self.handleButton(color))
                pixmap = QPixmap(16, 16)
                pixmap.fill(color)
                button.setIcon(QIcon(pixmap))
                layout.addWidget(button, row, column)
        self.setDefaultWidget(widget)

    def handleButton(self, color):
        self.parent().hide()
        self.colorSelected.emit(color)

    def palette(self):

        palette = []
        palette.append(QColor(Qt.black))
        palette.append(QColor(Qt.white))
        palette.append(QColor(Qt.red))
        palette.append(QColor(Qt.darkRed))
        palette.append(QColor(Qt.blue))
        palette.append(QColor(Qt.darkBlue))
        palette.append(QColor(Qt.green))
        palette.append(QColor(Qt.darkGreen))
        palette.append(QColor(Qt.yellow))

        return palette

class ColorMenu(QMenu):
    def __init__(self, parent):
        QMenu.__init__(self, parent)
        self.colorAction = ColorAction(self)
        self.colorAction.colorSelected.connect(self.handleColorSelected)
        self.addAction(self.colorAction)

    def handleColorSelected(self, color):
        self.color_atMenu = color
        self.emit(SIGNAL("colorChanged_atMenu()"))

    def get_color(self):
        return self.color_atMenu

class QColorButton(QPushButton):
    '''
    Custom Qt Widget to show a chosen color.

    Left-clicking the button shows the color-chooser, while
    right-clicking resets the color to None (no-color).
    '''

    colorChanged = pyqtSignal()

    def __init__(self, parent, *args, **kwargs):
        super(QColorButton, self).__init__(*args, **kwargs)
        self.parent = parent
        self._color = QColor(Qt.red)
        self.setMaximumWidth(32)
        self.myMenu = ColorMenu(self)
        self.pressed.connect(self.onColorPicker)
        self.connect(self.myMenu, SIGNAL("colorChanged_atMenu()"), self.handleMenu)

        self.setColor(self._color)

    def handleMenu(self):
        color = self.myMenu.get_color()
        self.setColor(color)

    def setColor(self, color):
        if color != self._color:
            self._color = color
            self.colorChanged.emit()
        if self._color:
            self.setStyleSheet("QPushButton {background-color: %s;"
                               "border-style: outset;"
                               "border-width: 1px;"
                               "border-radius: 10px;"
                               "border-color: beige;"
                               "min-width: 2em;"
                               "padding: 4px;}" % self._color.name())
        else:
            self.setStyleSheet("")

    def color(self):
        return self._color

    def onColorPicker(self):
        '''
        Show color-picker dialog to select color.

        Qt will use the native dialog by default.

        '''
        dlg = QColorDialog(self.parent)
        if self._color:
            dlg.setCurrentColor(self._color)

        if dlg.exec_():
            self.setColor(dlg.currentColor())

    def mousePressEvent(self, e):
        if e.button() == Qt.RightButton:
            point = QPoint()
            point.setX(e.x())   # -links +rechts
            point.setY(e.y() +10)   # -oben +unten
            self.myMenu.exec_(self.mapToGlobal(point))

        return super(QColorButton, self).mousePressEvent(e)


class Text_entry(object):

    def __init__(self, font, text, color):
        super(Text_entry, self).__init__()
        self.font = font
        self.text = text
        self.color = color
        self.__position = None

    def get_position(self):
        return self.__position if isinstance(self.__position, QRect) else None

    def set_position(self, new_pos):
        self.__position = new_pos if isinstance(new_pos, QRect) else None




if __name__ == "__main__":

    app = QApplication(sys.argv)
    app.setApplicationName("Snipping Tool")
    qt_translator = QTranslator()
    qt_translator.load("qt_" + QLocale.system().name(),
                       QLibraryInfo.location(QLibraryInfo.TranslationsPath))
    app.installTranslator(qt_translator)
    mainwindow = snipping_tool()
    mainwindow.setWindowTitle(u"Advanced Snipping Tool by Matthias")
    mainwindow.show()

    sys.exit(app.exec_())

'''
0.0.2 : Update Pfeilzeichnung, Farbe und Pinselstärke auswählbar.
0.0.3 : Versatzproblem gelöst, Einstellung Fullscreen war nicht gesetzt.
        Freihand-Zeichnung incl. wählbarer Farbe und Pinselbreite...
        Unterschiedliche Mauszeiger beim Vergrößern / Verkleinern / Verschieben einer Crop-Zone
        diverse kleine Fehler beseitigt und alles etwas "logischer"
0.0.4 : Zusätzliche Möglichkeit von Rechtecken und Ellipsen geschaffen
        Jetzt ist es möglich, alle "Zeichenfunktionen" auch im Scaliertem Modus (zoomed) durch zu führen!
0.0.5 : Wird vom Nutzer ein abweichender Pfad zum speichern eines Screenshots gewählt wird dieser für die Dauer
        der Sitzung gespeichert.
0.0.6 : Durch ein Update in Qt4 werden Icons in Context-Menüs nicht mehr automatisch angezeigt. Es ist erforderlich,
        dass ".setIconVisibleInMenu(True)" je Aktion aufgerufen wird, welche in Context-Menüs verwendet wird.
        daher wird nun in snippingtool.createContextMenue(self, point) jede Aktion mit o.g. Funktion aufgerufen
        (Zeile 864)
0.0.7 : Anderes Crop-Verhalten... wenn "zuschneiden" geklickt wurde, wird erst einmal nur ein dunkler Schleier über das 
        gesamte Bild gelegt. und der Mauszeiger in ein Kreuz umgewandelt, der Benutzer kann den Bereich erst einmal frei
        wählen und anschließend mittels der Ecken noch bearbeiten.
0.0.8 : Unterstützung für Screenshots wenn 2 Monitore angeschlossen sind (flexible Auswahl).
0.0.9 : Speichern von "letzer Speicherpfad", "letzte Fenstergröße" und "letzte Fensterposition" in den globalen
        Einstellungen
0.1.0 : Verticale Toolbar für Editor-Tools + Text kann hinzugefügt, verschoben, gelöscht werden
0.1.1 : About Menü
0.1.2 : App-Icon added

'''



