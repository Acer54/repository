#!/usr/bin/ python
# -*- coding: utf-8 -*-

# playToEnigma simply is generating a streaming video adress using youtube-dl

# requirements:

# notify-osd, notification-daemon, libnotify-bin
# zenity
# youtube-dl (use as current as possible)

# type youtube-dl >/dev/null 2>&1   # gives the path of youtube-dl 
# if [ $? -ne 0 ]  # if youtube-dl is not installed, it will download it later
# then
#    db_input critical webradio-py/youtube-dl || true
# fi
# echo "Install youtube-dl"
# wget http://yt-dl.org/downloads/latest/youtube-dl -O /usr/local/bin/youtube-dl
# chmod a+x /usr/local/bin/youtube-dl

import sys
import commands
import urllib
import json

# Credentials for enigma-receiver
# this will be set during installation and can be changed with "sudo dpkg-reconfigure playtoenigma
USER='root'
PASS='mypassword'
IP_ADR='192.168.178.37'


def excepthook(excType, excValue, traceback):
    print("Excet-Hook called")
    commands.getoutput("notify-send --icon=face-surprise 'Error: {0}'".format(traceback))

def main(argv):
    link = ""
    if len(argv) > 1:
        link = argv[1]
    else:
        link = commands.getoutput("zenity --entry --title='Geben Sie eine Video-URL ein:' --text='Video-Url:' 2> /dev/null")
    if link != "":
        dirty_link = commands.getoutput("youtube-dl -g -f best[ext=mp4]" + ' "' + "{0}".format(link) + '" ' + "2> /dev/null")
        cleaned_link = urllib.quote(dirty_link).replace('%3A', '%253A')
        if cleaned_link.startswith("http"):
            #urllib.urlopen("http://root:mysecretpass@192.168.178.37/web/mediaplayerplay?file=4097:0:1:0:0:0:0:0:0:0:" + cleaned_link)
            urllib.urlopen("http://{0}:{1}@{2}/web/mediaplayerplay?file=4097:0:1:0:0:0:0:0:0:0:{3}".format(USER, PASS, IP_ADR, cleaned_link))
        else:
            commands.getoutput("notify-send --icon=face-surprise 'Error playing: {0}'".format(link))

if __name__ == "__main__":
    main(sys.argv)
    sys.excepthook = excepthook
    sys.exit(0) # return 0 (Process successful)
